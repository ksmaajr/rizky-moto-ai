<?php

use Livewire\Attributes\Layout;
use Livewire\Component;

new
#[Layout('layouts::app')]
class extends Component
{
    public function getUserProperty(): ?object
    {
        return auth()->user();
    }

    public string $activeSection = 'dashboard';

    public function getUserInitialsProperty(): string
    {
        $name = trim((string) ($this->user?->name ?? 'User'));
        $parts = preg_split('/\s+/', $name) ?: [];

        return collect($parts)
            ->filter()
            ->take(2)
            ->map(fn ($part) => strtoupper(substr($part, 0, 1)))
            ->implode('') ?: 'U';
    }

    public function openStore(): void
    {
        $this->activeSection = 'stores';
    }

    public function openDashboard(): void
    {
        $this->activeSection = 'dashboard';
    }
};

?>

<div class="min-h-screen bg-[#f4f4f5] text-zinc-950">

    {{-- Ambient page background --}}
    <div class="pointer-events-none fixed inset-0 overflow-hidden">
        <div class="absolute -left-32 -top-32 h-96 w-96 rounded-full bg-red-500/[0.045] blur-3xl"></div>
        <div class="absolute -bottom-48 right-0 h-[32rem] w-[32rem] rounded-full bg-zinc-900/[0.035] blur-3xl"></div>
    </div>

    {{-- MOBILE OVERLAY --}}
    <div id="mobileOverlay" class="dashboard-overlay"></div>

    {{-- SIDEBAR --}}
    <aside id="dashboardSidebar" class="dashboard-sidebar">

        {{-- Sidebar ambient glow --}}
        <div class="sidebar-glow sidebar-glow-red"></div>
        <div class="sidebar-glow sidebar-glow-white"></div>

        {{-- BRAND / LOGO ONLY --}}
        <div class="sidebar-brand">
            <div class="brand-logo-wrap">
                <img
                    src="{{ asset('images/logo-rizky-moto-shop.png') }}"
                    alt="Rizky Moto Shop"
                    class="brand-logo"
                >
            </div>

            <button
                type="button"
                class="mobile-close"
                onclick="closeMobileSidebar()"
                aria-label="Close sidebar"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                    <path d="M6 6l12 12M18 6 6 18"/>
                </svg>
            </button>
        </div>

        {{-- NAVIGATION --}}
        <div class="sidebar-scroll">

            <div class="nav-section">
                <div class="nav-heading">Workspace</div>

                <div class="nav-list">
                    <button type="button" class="nav-item" :class="{ active: $wire.activeSection === 'dashboard' }" wire:click="openDashboard">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <rect x="3" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="14" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="3" y="14" width="7" height="7" rx="1.5"/>
                                <rect x="14" y="14" width="7" height="7" rx="1.5"/>
                            </svg>
                        </span>
                        <span class="nav-label">Dashboard</span>
                    </button>

                    <button type="button" class="nav-item">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/>
                                <path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z"/>
                            </svg>
                        </span>
                        <span class="nav-label">Product Generator</span>
                        <span class="nav-pill">AI</span>
                    </button>
                </div>
            </div>

            <div class="nav-section">
                <div class="nav-heading">Management</div>

                <div class="nav-list">
                    <button type="button" class="nav-item" :class="{ active: $wire.activeSection === 'stores' }" wire:click="openStore">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="M4 10h16"/>
                                <path d="M5 10v9h14v-9"/>
                                <path d="M3 10 5 4h14l2 6"/>
                                <path d="M8 14h8"/>
                            </svg>
                        </span>
                        <span class="nav-label">Stores</span>
                    </button>

                    <button type="button" class="nav-item">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <rect x="3" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="14" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="3" y="14" width="18" height="7" rx="1.5"/>
                            </svg>
                        </span>
                        <span class="nav-label">Templates</span>
                    </button>

                    <button type="button" class="nav-item">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <rect x="3" y="3" width="18" height="18" rx="3"/>
                                <path d="m7 16 4-4 3 3 3-5"/>
                            </svg>
                        </span>
                        <span class="nav-label">Generations</span>
                    </button>

                    <button type="button" class="nav-item">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>
                            </svg>
                        </span>
                        <span class="nav-label">Favorites</span>
                    </button>
                </div>
            </div>

            <div class="nav-section">
                <div class="nav-heading">System</div>

                <div class="nav-list">
                    <button type="button" class="nav-item">
                        <span class="nav-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="M12 3v2"/>
                                <path d="M12 19v2"/>
                                <path d="m4.2 4.2 1.4 1.4"/>
                                <path d="m18.4 18.4 1.4 1.4"/>
                                <path d="M3 12h2"/>
                                <path d="M19 12h2"/>
                                <path d="m4.2 19.8 1.4-1.4"/>
                                <path d="m18.4 5.6 1.4-1.4"/>
                                <circle cx="12" cy="12" r="4"/>
                            </svg>
                        </span>
                        <span class="nav-label">Settings</span>
                    </button>
                </div>
            </div>

        </div>

        {{-- OPENAI API STATUS --}}
        <div class="sidebar-api">
            <div class="api-status-card">
                <div class="api-status-top">
                    <div class="api-brand">
                        <span class="api-mark">AI</span>
                        <div>
                            <div class="api-title">OpenAI API</div>
                            <div class="api-subtitle">Creative engine</div>
                        </div>
                    </div>
                    <span class="api-live-dot" aria-hidden="true"></span>
                </div>

                <div class="api-status-row">
                    <span class="api-status-dot"></span>
                    <span>Ready to connect</span>
                    <span class="api-status-badge">STEP 0</span>
                </div>
            </div>
        </div>
    </aside>


    {{-- MAIN AREA --}}
    <div class="dashboard-main">

        {{-- TOPBAR --}}
        <header class="topbar">
            <div class="topbar-left">

                <button
                    type="button"
                    class="mobile-menu"
                    onclick="openMobileSidebar()"
                    aria-label="Open sidebar"
                >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <path d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>

                <div class="topbar-title">
                    <div class="topbar-eyebrow">
                        <span></span>
                        Workspace
                    </div>
                    <div class="topbar-heading">AI Creative Dashboard</div>
                </div>
            </div>

            <div class="topbar-right">

                <div class="top-search">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                        <circle cx="11" cy="11" r="7"/>
                        <path d="m20 20-4-4"/>
                    </svg>
                    <input type="text" placeholder="Search workspace...">
                    <span class="search-shortcut">⌘ K</span>
                </div>

                {{-- NOTIFICATION MENU --}}
                <div class="notification-menu" id="notificationMenu">
                    <button
                        type="button"
                        class="topbar-button notification-button"
                        id="notificationButton"
                        aria-label="Notifications"
                        aria-expanded="false"
                        aria-haspopup="true"
                    >
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/>
                            <path d="M10 21h4"/>
                        </svg>
                        <span class="notification-dot"></span>
                        <span class="notification-count">4</span>
                    </button>

                    <div
                        class="notification-dropdown"
                        id="notificationDropdown"
                        aria-hidden="true"
                    >
                        <div class="notification-dropdown-head">
                            <div>
                                <span class="notification-eyebrow">SYSTEM CENTER</span>
                                <h3>Notifikasi</h3>
                                <p>Update terbaru dari workspace kamu.</p>
                            </div>

                            <button type="button" class="notification-mark-read" id="notificationMarkRead">
                                Tandai dibaca
                            </button>
                        </div>

                        <div class="notification-list">
                            <button type="button" class="notification-item is-unread">
                                <span class="notification-item-icon notification-icon-red">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                        <path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/>
                                        <path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z"/>
                                    </svg>
                                </span>
                                <span class="notification-item-content">
                                    <strong>AI Creative Engine siap digunakan</strong>
                                    <span>Workspace visual berhasil dimuat dan siap untuk proses berikutnya.</span>
                                    <small>Baru saja</small>
                                </span>
                                <span class="notification-unread-dot"></span>
                            </button>

                            <button type="button" class="notification-item is-unread">
                                <span class="notification-item-icon notification-icon-green">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                        <path d="M20 6 9 17l-5-5"/>
                                    </svg>
                                </span>
                                <span class="notification-item-content">
                                    <strong>OpenAI API status: Ready</strong>
                                    <span>Koneksi engine kreatif tersedia untuk tahap konfigurasi.</span>
                                    <small>2 menit lalu</small>
                                </span>
                                <span class="notification-unread-dot"></span>
                            </button>

                            <button type="button" class="notification-item">
                                <span class="notification-item-icon notification-icon-dark">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                        <rect x="3" y="3" width="18" height="18" rx="3"/>
                                        <path d="M7 8h10M7 12h7M7 16h5"/>
                                    </svg>
                                </span>
                                <span class="notification-item-content">
                                    <strong>Template workspace diperbarui</strong>
                                    <span>Template visual baru akan muncul di Template Library.</span>
                                    <small>18 menit lalu</small>
                                </span>
                            </button>

                            <button type="button" class="notification-item">
                                <span class="notification-item-icon notification-icon-violet">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                        <path d="M12 3v18M3 12h18"/>
                                        <circle cx="12" cy="12" r="8"/>
                                    </svg>
                                </span>
                                <span class="notification-item-content">
                                    <strong>Dashboard berhasil diperbarui</strong>
                                    <span>UI workspace Rizky Moto Shop menggunakan tampilan terbaru.</span>
                                    <small>1 jam lalu</small>
                                </span>
                            </button>
                        </div>

                        <div class="notification-dropdown-footer">
                            <span><i></i> Internal workspace</span>
                            <button type="button" id="notificationClose">Tutup</button>
                        </div>
                    </div>
                </div>

                <div class="topbar-divider"></div>

                {{-- PROFILE MENU --}}
                <div class="profile-menu" id="profileMenu">

                    <button
                        type="button"
                        class="profile-button"
                        id="profileButton"
                        aria-expanded="false"
                        aria-haspopup="true"
                    >
                        <span class="profile-avatar">
                            {{ $this->userInitials }}
                        </span>

                        <span class="profile-info">
                            <span class="profile-name">
                                {{ $this->user?->name ?? 'User' }}
                            </span>

                            <span class="profile-role">
                                Administrator
                            </span>
                        </span>

                        <svg
                            class="profile-chevron"
                            id="profileChevron"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path d="m6 9 6 6 6-6"/>
                        </svg>
                    </button>

                    <div
                        class="profile-dropdown"
                        id="profileDropdown"
                        aria-hidden="true"
                    >
                        <div class="profile-dropdown-header">
                            <div class="profile-dropdown-avatar">
                                {{ $this->userInitials }}
                            </div>

                            <div class="profile-dropdown-identity">
                                <strong>
                                    {{ $this->user?->name ?? 'User' }}
                                </strong>

                                <span>
                                    {{ $this->user?->email ?? '-' }}
                                </span>
                            </div>
                        </div>

                        <div class="profile-dropdown-divider"></div>

                        <button
                            type="button"
                            class="profile-dropdown-item"
                            data-profile-settings
                        >
                            <span class="profile-dropdown-icon">
                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.7"
                                >
                                    <circle cx="12" cy="12" r="3"/>
                                    <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.8 1.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5v.2h-2.5v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1-1.8-1.8.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H6.5v-2.5h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1 1.8-1.8.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V4h2.5v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1 1.8 1.8-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0-1.5 1h.2v2.5h-.2a1.7 1.7 0 0 0-1.5 1.4Z"/>
                                </svg>
                            </span>

                            <span class="profile-dropdown-text">
                                <strong>Pengaturan Akun</strong>
                                <small>Kelola profil dan akun</small>
                            </span>
                        </button>

                        <div class="profile-dropdown-divider"></div>

                        <form
                            method="POST"
                            action="{{ route('logout') }}"
                            class="profile-logout-form"
                        >
                            @csrf

                            <button
                                type="submit"
                                class="profile-dropdown-item profile-logout"
                            >
                                <span class="profile-dropdown-icon">
                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="1.7"
                                    >
                                        <path d="M10 17l5-5-5-5"/>
                                        <path d="M15 12H3"/>
                                        <path d="M21 4v16"/>
                                    </svg>
                                </span>

                                <span class="profile-dropdown-text">
                                    <strong>Keluar</strong>
                                    <small>Keluar dari akun internal</small>
                                </span>
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        </header>


        {{-- DASHBOARD CONTENT --}}
        <main class="dashboard-content">

       

            {{-- =========================================================
                 PREMIUM PAGE INTRO
                 ======================================================== --}}
            <section class="workspace-intro reveal reveal-1">

                <div class="workspace-intro-copy">
                    <div class="eyebrow-label">
                        <span class="eyebrow-dot"></span>
                        INTERNAL CREATIVE WORKSPACE
                    </div>

                    <h1 class="page-title">
                        Good afternoon,
                        <span>{{ $this->user?->name ?? 'User' }}.</span>
                    </h1>

                    <p class="page-description">
                        Satu workspace terpusat untuk mengelola visual produk,
                        Store, Template, dan aktivitas AI Rizky Moto Shop.
                    </p>

                    <div class="workspace-meta">
                        <span class="workspace-meta-item">
                            <i></i>
                            Workspace active
                        </span>

                        <span class="workspace-meta-divider"></span>

                        <span class="workspace-meta-item muted">
                            Last sync just now
                        </span>
                    </div>
                </div>

                <div class="workspace-intro-status">
                    <span class="system-status-dot"></span>

                    <div>
                        <span class="system-status-title">All Systems</span>
                        <span class="system-status-subtitle">Operational</span>
                    </div>

                    <span class="system-status-arrow">↗</span>
                </div>

            </section>


            {{-- =========================================================
                 HERO — AI CREATIVE ENGINE
                 ========================================================= --}}
            <section class="premium-hero reveal reveal-2">

                <div class="premium-hero-grid"></div>
                <div class="premium-hero-noise"></div>

                <div class="premium-hero-glow premium-hero-glow-red"></div>
                <div class="premium-hero-glow premium-hero-glow-white"></div>

                <div class="premium-hero-content">

                    <div class="hero-kicker">
                        <span class="hero-kicker-dot"></span>
                        AI CREATIVE ENGINE
                    </div>

                    <h2 class="premium-hero-title">
                        From product photo
                        <span>to marketplace-ready.</span>
                    </h2>

                    <p class="premium-hero-description">
                        Siapkan bahan visual, gunakan preset Template,
                        lalu biarkan creative engine membantu menghasilkan
                        visual produk yang konsisten.
                    </p>

                    <div class="premium-hero-actions">
                        <button type="button" class="hero-primary">
                            <span class="sparkle-icon">✦</span>
                            Product Generator
                            <span class="button-arrow">→</span>
                        </button>

                        <button type="button" class="hero-secondary">
                            Explore Workspace
                            <span>↗</span>
                        </button>
                    </div>

                    <div class="hero-trust-row">
                        <span class="hero-trust-item">
                            <i></i>
                            Internal workspace
                        </span>

                        <span class="hero-trust-item">
                            <i></i>
                            Template based
                        </span>

                        <span class="hero-trust-item">
                            <i></i>
                            AI ready
                        </span>
                    </div>

                </div>


                {{-- AI PIPELINE VISUAL --}}
                <div class="ai-engine-visual">

                    <div class="engine-orbit engine-orbit-a"></div>
                    <div class="engine-orbit engine-orbit-b"></div>
                    <div class="engine-orbit engine-orbit-c"></div>

                    <div class="engine-scan-line"></div>

                    <div class="engine-core">
                        <div class="engine-core-ring"></div>
                        <div class="engine-core-inner">
                            <span class="engine-core-label">AI</span>
                            <small>ENGINE</small>
                        </div>
                    </div>

                    <div class="engine-node engine-node-img">
                        <span class="engine-node-icon">IMG</span>
                        <small>Product</small>
                    </div>

                    <div class="engine-node engine-node-style">
                        <span class="engine-node-icon">✦</span>
                        <small>Style</small>
                    </div>

                    <div class="engine-node engine-node-shop">
                        <span class="engine-node-icon">▣</span>
                        <small>Store</small>
                    </div>

                    <div class="engine-connection engine-connection-1"></div>
                    <div class="engine-connection engine-connection-2"></div>
                    <div class="engine-connection engine-connection-3"></div>

                </div>

                <div class="premium-hero-footer">
                    <span>RIZKY MOTO SHOP</span>
                    <span class="premium-hero-footer-line"></span>
                    <span>CREATIVE SYSTEM / 01</span>
                </div>

            </section>


            {{-- =========================================================
                 KPI / WORKSPACE OVERVIEW
                 ========================================================= --}}
            <section class="dashboard-section-heading reveal reveal-3">
                <div>
                    <span class="section-kicker">WORKSPACE OVERVIEW</span>
                    <h2>Creative activity</h2>
                </div>

                <span class="section-live">
                    <i></i>
                    LIVE DATA
                </span>
            </section>


            <section class="premium-stats-grid reveal reveal-3">

                {{-- STORES --}}
                <article class="premium-stat-card premium-stat-red">

                    <div class="premium-stat-top">
                        <div class="premium-stat-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="M4 10h16"/>
                                <path d="M5 10v9h14v-9"/>
                                <path d="M3 10 5 4h14l2 6"/>
                            </svg>
                        </div>

                        <span class="premium-stat-status live">
                            <i></i>
                            LIVE
                        </span>
                    </div>

                    <div class="premium-stat-label">Active Stores</div>
                    <div class="premium-stat-value">04</div>

                    <div class="premium-stat-bottom">
                        <span>Connected marketplace stores</span>
                        <strong>100%</strong>
                    </div>

                    <div class="premium-stat-progress">
                        <span style="width: 100%"></span>
                    </div>

                </article>


                {{-- TEMPLATES --}}
                <article class="premium-stat-card">

                    <div class="premium-stat-top">
                        <div class="premium-stat-icon violet">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <rect x="3" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="14" y="3" width="7" height="7" rx="1.5"/>
                                <rect x="3" y="14" width="18" height="7" rx="1.5"/>
                            </svg>
                        </div>

                        <span class="premium-stat-status">
                            READY
                        </span>
                    </div>

                    <div class="premium-stat-label">Templates</div>
                    <div class="premium-stat-value">12</div>

                    <div class="premium-stat-bottom">
                        <span>Configured visual templates</span>
                        <strong>12 / 20</strong>
                    </div>

                    <div class="premium-stat-progress violet">
                        <span style="width: 60%"></span>
                    </div>

                </article>


                {{-- GENERATIONS --}}
                <article class="premium-stat-card">

                    <div class="premium-stat-top">
                        <div class="premium-stat-icon orange">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <rect x="3" y="3" width="18" height="18" rx="3"/>
                                <path d="m7 16 4-4 3 3 3-5"/>
                            </svg>
                        </div>

                        <span class="premium-stat-status">
                            TOTAL
                        </span>
                    </div>

                    <div class="premium-stat-label">Generations</div>
                    <div class="premium-stat-value">128</div>

                    <div class="premium-stat-bottom">
                        <span>Visuals generated</span>
                        <strong>+18%</strong>
                    </div>

                    <div class="premium-stat-progress orange">
                        <span style="width: 78%"></span>
                    </div>

                </article>


                {{-- FAVORITES --}}
                <article class="premium-stat-card">

                    <div class="premium-stat-top">
                        <div class="premium-stat-icon green">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                                <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>
                            </svg>
                        </div>

                        <span class="premium-stat-status">
                            SAVED
                        </span>
                    </div>

                    <div class="premium-stat-label">Favorites</div>
                    <div class="premium-stat-value">24</div>

                    <div class="premium-stat-bottom">
                        <span>Saved visual results</span>
                        <strong>24 saved</strong>
                    </div>

                    <div class="premium-stat-progress green">
                        <span style="width: 48%"></span>
                    </div>

                </article>

            </section>


            {{-- =========================================================
                 LOWER WORKSPACE
                 ========================================================= --}}
            <section class="premium-lower-grid reveal reveal-4">

                {{-- QUICK ACCESS --}}
                <div class="premium-content-card quick-card">

                    <div class="premium-card-heading">
                        <div>
                            <span class="section-kicker">WORKSPACE</span>
                            <h3>Quick access</h3>
                            <p>Shortcut untuk aktivitas yang paling sering digunakan.</p>
                        </div>

                        <span class="card-index">01</span>
                    </div>


                    <div class="premium-quick-list">

                        <div class="premium-quick-item">
                            <div class="premium-quick-icon red">
                                <span>✦</span>
                            </div>

                            <div class="premium-quick-copy">
                                <strong>Product Generator</strong>
                                <span>Create a new product visual</span>
                            </div>

                            <span class="premium-quick-arrow">↗</span>
                        </div>


                        <div class="premium-quick-item">
                            <div class="premium-quick-icon dark">
                                <span>▣</span>
                            </div>

                            <div class="premium-quick-copy">
                                <strong>Store Management</strong>
                                <span>Manage marketplace identity</span>
                            </div>

                            <span class="premium-quick-arrow">↗</span>
                        </div>


                        <div class="premium-quick-item">
                            <div class="premium-quick-icon violet">
                                <span>▦</span>
                            </div>

                            <div class="premium-quick-copy">
                                <strong>Template Library</strong>
                                <span>Manage visual presets</span>
                            </div>

                            <span class="premium-quick-arrow">↗</span>
                        </div>

                    </div>

                </div>


                {{-- RECENT ACTIVITY --}}
                <div class="premium-content-card activity-card">

                    <div class="premium-card-heading">
                        <div>
                            <span class="section-kicker">ACTIVITY</span>
                            <h3>Recent generations</h3>
                            <p>Visual terbaru yang dibuat dari creative engine.</p>
                        </div>

                        <button type="button" class="premium-view-all">
                            View all
                            <span>→</span>
                        </button>
                    </div>


                    <div class="premium-activity-empty">

                        <div class="activity-visual">

                            <div class="activity-visual-ring ring-one"></div>
                            <div class="activity-visual-ring ring-two"></div>

                            <div class="activity-visual-core">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                    <rect x="3" y="3" width="18" height="18" rx="3"/>
                                    <path d="m7 16 4-4 3 3 3-5"/>
                                </svg>
                            </div>

                            <span class="activity-node activity-node-one">IMG</span>
                            <span class="activity-node activity-node-two">AI</span>
                            <span class="activity-node activity-node-three">SHOP</span>

                        </div>

                        <div class="premium-empty-copy">
                            <strong>Your creative space is ready.</strong>
                            <span>
                                Generated visuals will appear here once the
                                AI generator starts creating results.
                            </span>
                        </div>

                        <div class="premium-empty-status">
                            <i></i>
                            Waiting for first generation
                        </div>

                    </div>

                </div>

            </section>


            {{-- =========================================================
                 SYSTEM / BRAND FOOTER
                 ========================================================= --}}
            <section class="premium-system-strip reveal reveal-5">

                <div class="premium-system-brand">

                    <div class="mini-logo">
                        <img
                            src="{{ asset('images/logo-rizky-moto-shop.png') }}"
                            alt="Rizky Moto Shop"
                        >
                    </div>

                    <div>
                        <strong>Rizky Moto Shop AI Tools</strong>
                        <span>Internal creative workspace</span>
                    </div>

                </div>


                <div class="premium-system-info">

                    <span class="premium-system-online">
                        <i></i>
                        System online
                    </span>

                    <span class="premium-system-divider"></span>

                    <span class="premium-system-version">
                        BUILD 01.00
                    </span>

                </div>

            </section>

       

        </main>
    </div>
</div>


