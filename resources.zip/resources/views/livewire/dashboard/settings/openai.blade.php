<div class="rms-settings-page" wire:key="settings-openai-root">
    <section class="rms-settings-hero rms-settings-reveal">
        <div class="rms-settings-hero-grid"></div>
        <div class="rms-settings-hero-glow"></div>

        <span class="rms-settings-eyebrow"><i></i> WORKSPACE / SETTINGS</span>

        <div class="rms-settings-hero-row">
            <div>
                <h1>OpenAI API <span>Configuration.</span></h1>
                <p>Kelola koneksi creative engine yang digunakan oleh Product Generator.</p>
            </div>

            <span class="rms-settings-status-pill">
                <i></i> INTERNAL CONFIGURATION
            </span>
        </div>

        <div class="rms-settings-meta">
            <span><i></i> Creative engine workspace active</span>
            <b></b>
            <span>OpenAI API</span>
            <span>Ready to configure</span>
        </div>
    </section>

    <section class="rms-settings-openai-card rms-settings-reveal" style="--reveal-delay:.06s">
        <div class="rms-settings-openai-head">
            <div class="rms-settings-engine-icon"><span>AI</span></div>

            <div>
                <span>CREATIVE ENGINE</span>
                <h2>OpenAI API</h2>
                <p>Connection &amp; generation configuration</p>
            </div>

            <span class="rms-settings-ready"><i></i> Ready to configure</span>
        </div>

        <div class="rms-settings-openai-form">
            <label class="rms-settings-field">
                <span>API Key</span>
                <div class="rms-settings-input-wrap" x-data="{ visible:false }">
                    <input
                        type="password"
                        :type="visible ? 'text' : 'password'"
                        value=""
                        placeholder="Masukkan OpenAI API key"
                        autocomplete="off"
                    >
                    <button type="button" @click="visible=!visible" x-text="visible ? 'Hide' : 'View'"></button>
                </div>
                <small>API key hanya digunakan oleh server untuk proses generate gambar.</small>
            </label>

            <label class="rms-settings-field">
                <span>Image Model</span>
                <select>
                    <option>OpenAI Image Generation</option>
                    <option>gpt-image-1</option>
                </select>
                <small>Model yang digunakan Product Generator.</small>
            </label>
        </div>

        <div class="rms-settings-connection">
            <div class="rms-settings-connection-copy">
                <div class="rms-settings-check">✓</div>
                <div>
                    <strong>API configuration</strong>
                    <p>UI sudah disiapkan untuk koneksi OpenAI. Penyimpanan credential dapat disambungkan pada tahap backend.</p>
                </div>
            </div>

            <button type="button" class="rms-settings-test-button">
                Test Connection <b>→</b>
            </button>
        </div>
    </section>

    <section class="rms-settings-logs rms-settings-reveal" style="--reveal-delay:.1s">
        <div class="rms-settings-logs-head">
            <div>
                <span class="rms-settings-terminal-icon">›_</span>
                <div>
                    <strong>Connection Logs</strong>
                    <small>Aktivitas test koneksi OpenAI akan tampil di panel ini.</small>
                </div>
            </div>

            <div class="rms-settings-log-actions">
                <span><i></i> WAITING FOR TEST</span>
                <button type="button">Clear</button>
            </div>
        </div>

        <div class="rms-settings-log-empty">
            <div class="rms-settings-log-icon">›_</div>
            <strong>No connection activity yet.</strong>
            <p>Jalankan Test Connection setelah backend credential dan endpoint OpenAI diaktifkan.</p>
        </div>
    </section>
</div>
