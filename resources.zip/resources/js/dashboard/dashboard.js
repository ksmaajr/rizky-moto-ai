/* ========================================================================
   RIZKY MOTO SHOP — DASHBOARD UI / STEP 1
   Workspace section switching — visual only
   ======================================================================== */
(function () {
    const init = () => {
        const shell = document.querySelector('[data-dashboard-workspace]') || document;
        const sections = [...shell.querySelectorAll('[data-workspace-section]')];
        const navItems = [...shell.querySelectorAll('[data-workspace-nav]')];
        if (!sections.length) return;

        const showSection = (name) => {
            sections.forEach((section) => {
                const active = section.dataset.workspaceSection === name;
                section.classList.toggle('is-active', active);
                section.setAttribute('aria-hidden', active ? 'false' : 'true');
            });
            navItems.forEach((item) => {
                const active = item.dataset.workspaceNav === name;
                item.classList.toggle('is-active', active);
                item.setAttribute('aria-current', active ? 'page' : 'false');
            });
            window.scrollTo({ top: 0, behavior: 'smooth' });
        };

        navItems.forEach((item) => {
            if (item.dataset.bound === 'true') return;
            item.dataset.bound = 'true';
            item.addEventListener('click', (event) => {
                event.preventDefault();
                showSection(item.dataset.workspaceNav);
            });
        });

        shell.querySelectorAll('[data-store-action]').forEach((button) => {
            if (button.dataset.bound === 'true') return;
            button.dataset.bound = 'true';
            button.addEventListener('click', () => {
                const action = button.dataset.storeAction;
                if (window.RMS?.toast?.info) {
                    window.RMS.toast.info(
                        action === 'add' ? 'Store Workspace' : 'Store Preview',
                        action === 'add' ? 'Form Add Store akan diaktifkan pada tahap fungsi.' : 'Detail Store akan diaktifkan pada tahap fungsi.'
                    );
                }
            });
        });

        const search = shell.querySelector('.rms-store-search input');
        if (search && search.dataset.bound !== 'true') {
            search.dataset.bound = 'true';
            search.addEventListener('input', () => {
                const keyword = search.value.trim().toLowerCase();
                shell.querySelectorAll('.rms-store-card').forEach((card) => {
                    const name = card.dataset.storeName || '';
                    card.style.display = !keyword || name.includes(keyword) ? '' : 'none';
                });
            });
        }
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
    else init();
    document.addEventListener('livewire:navigated', init);
    document.addEventListener('livewire:init', init);
})();
