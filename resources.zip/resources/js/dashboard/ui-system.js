/* RMS Universal UI System — interaction only. No dashboard layout code. */
(() => {
    'use strict';

    const qs = (s, root = document) => root.querySelector(s);
    const qsa = (s, root = document) => [...root.querySelectorAll(s)];

    function initDashboardUI() {
        const sidebar = qs('#dashboardSidebar');
        const overlay = qs('#mobileOverlay');
        const mobileMenu = qs('.mobile-menu');
        const notificationMenu = qs('#notificationMenu');
        const notificationButton = qs('#notificationButton');
        const notificationDropdown = qs('#notificationDropdown');
        const notificationClose = qs('#notificationClose');
        const notificationMarkRead = qs('#notificationMarkRead');
        const profileMenu = qs('#profileMenu');
        const profileButton = qs('#profileButton');
        const profileDropdown = qs('#profileDropdown');

        const closeNotification = () => {
            notificationMenu?.classList.remove('is-open');
            notificationButton?.setAttribute('aria-expanded', 'false');
            notificationDropdown?.setAttribute('aria-hidden', 'true');
        };
        const openNotification = () => {
            profileMenu?.classList.remove('is-open');
            profileButton?.setAttribute('aria-expanded', 'false');
            notificationMenu?.classList.add('is-open');
            notificationButton?.setAttribute('aria-expanded', 'true');
            notificationDropdown?.setAttribute('aria-hidden', 'false');
        };
        const closeProfile = () => {
            profileMenu?.classList.remove('is-open');
            profileButton?.setAttribute('aria-expanded', 'false');
            profileDropdown?.setAttribute('aria-hidden', 'true');
        };
        const openProfile = () => {
            closeNotification();
            profileMenu?.classList.add('is-open');
            profileButton?.setAttribute('aria-expanded', 'true');
            profileDropdown?.setAttribute('aria-hidden', 'false');
        };
        const closeAllMenus = () => { closeNotification(); closeProfile(); };

        const openMobileSidebar = () => {
            sidebar?.classList.add('mobile-open');
            overlay?.classList.add('mobile-visible');
            document.body.classList.add('overflow-hidden');
        };
        const closeMobileSidebar = () => {
            sidebar?.classList.remove('mobile-open');
            overlay?.classList.remove('mobile-visible');
            document.body.classList.remove('overflow-hidden');
        };

        window.openMobileSidebar = openMobileSidebar;
        window.closeMobileSidebar = closeMobileSidebar;

        if (mobileMenu && !mobileMenu.dataset.rmsBound) {
            mobileMenu.dataset.rmsBound = '1';
            mobileMenu.addEventListener('click', e => { e.preventDefault(); openMobileSidebar(); });
        }
        if (overlay && !overlay.dataset.rmsBound) {
            overlay.dataset.rmsBound = '1';
            overlay.addEventListener('click', closeMobileSidebar);
        }
        if (notificationButton && !notificationButton.dataset.rmsBound) {
            notificationButton.dataset.rmsBound = '1';
            notificationButton.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); notificationMenu?.classList.contains('is-open') ? closeNotification() : openNotification(); });
        }
        if (notificationClose && !notificationClose.dataset.rmsBound) {
            notificationClose.dataset.rmsBound = '1'; notificationClose.addEventListener('click', closeNotification);
        }
        if (notificationMarkRead && !notificationMarkRead.dataset.rmsBound) {
            notificationMarkRead.dataset.rmsBound = '1'; notificationMarkRead.addEventListener('click', () => { qsa('.notification-unread-dot', notificationDropdown).forEach(el => el.remove()); qs('.notification-dot')?.classList.add('is-hidden'); qs('.notification-count')?.classList.add('is-hidden'); });
        }
        if (profileButton && !profileButton.dataset.rmsBound) {
            profileButton.dataset.rmsBound = '1';
            profileButton.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); profileMenu?.classList.contains('is-open') ? closeProfile() : openProfile(); });
        }
        if (!document.documentElement.dataset.rmsGlobalBound) {
            document.documentElement.dataset.rmsGlobalBound = '1';
            document.addEventListener('click', e => {
                if (!notificationMenu?.contains(e.target) && !profileMenu?.contains(e.target)) closeAllMenus();
            });
            document.addEventListener('keydown', e => {
                if (e.key === 'Escape') { closeAllMenus(); closeMobileSidebar(); RMS?.confirm?.close?.(); }
            });
        }
    }

    function ensureToastStack() {
        let stack = qs('#rmsToastStack');
        if (!stack) { stack = document.createElement('div'); stack.id = 'rmsToastStack'; stack.className = 'rms-ui-toast-stack'; document.body.appendChild(stack); }
        return stack;
    }

    function toast(type, title, message = '', duration = 3200) {
        const stack = ensureToastStack();
        const item = document.createElement('div'); item.className = `rms-ui-toast is-${type}`;
        const icons = {success:'✓',error:'!',warning:'!',info:'i',loading:'•'};
        item.innerHTML = `<div class="rms-ui-toast-icon is-${type}">${icons[type] || 'i'}</div><div class="rms-ui-toast-copy"><strong></strong><span></span></div><button type="button" class="rms-ui-toast-close" aria-label="Close">×</button><div class="rms-ui-toast-progress"></div>`;
        qs('strong', item).textContent = title; qs('span', item).textContent = message;
        const close = () => { item.classList.add('is-leaving'); setTimeout(() => item.remove(), 290); };
        qs('.rms-ui-toast-close', item).addEventListener('click', close); stack.appendChild(item);
        if (duration > 0) { const bar = qs('.rms-ui-toast-progress', item); bar.style.animation = `rmsToastProgress ${duration}ms linear forwards`; setTimeout(close, duration); }
        return { close };
    }

    function ensureConfirm() {
        let root = qs('#rmsConfirm'); if (root) return root;
        root = document.createElement('div'); root.id='rmsConfirm'; root.className='rms-ui-confirm-backdrop';
        root.innerHTML='<div class="rms-ui-confirm" role="dialog" aria-modal="true"><div class="rms-ui-confirm-icon">!</div><h3></h3><p></p><div class="rms-ui-confirm-actions"><button type="button" class="rms-ui-confirm-cancel">Batal</button><button type="button" class="rms-ui-confirm-ok">Konfirmasi</button></div></div>';
        document.body.appendChild(root); return root;
    }
    let confirmResolver = null;
    function confirm(options={}) { const root=ensureConfirm(); qs('h3',root).textContent=options.title||'Konfirmasi'; qs('p',root).textContent=options.message||'Lanjutkan tindakan ini?'; qs('.rms-ui-confirm-ok',root).textContent=options.confirmText||'Konfirmasi'; qs('.rms-ui-confirm-cancel',root).textContent=options.cancelText||'Batal'; root.classList.add('is-open'); return new Promise(resolve=>{confirmResolver=resolve;}); }
    function closeConfirm(value=false){const root=qs('#rmsConfirm'); root?.classList.remove('is-open'); if(confirmResolver){const r=confirmResolver;confirmResolver=null;r(value)}}

    window.RMS = window.RMS || {};
    window.RMS.toast = { success:(t,m,d)=>toast('success',t,m,d), error:(t,m,d)=>toast('error',t,m,d), warning:(t,m,d)=>toast('warning',t,m,d), info:(t,m,d)=>toast('info',t,m,d), loading:(t,m)=>toast('loading',t,m,0) };
    window.RMS.confirm = Object.assign((options)=>confirm(options), {close:()=>closeConfirm(false)});

    document.addEventListener('click', e => {
        if (e.target.closest('.rms-ui-confirm-cancel')) closeConfirm(false);
        if (e.target.closest('.rms-ui-confirm-ok')) closeConfirm(true);
        if (e.target.id === 'rmsConfirm') closeConfirm(false);
    });

    function runInit(){ initDashboardUI(); }
    document.addEventListener('DOMContentLoaded', runInit);
    document.addEventListener('livewire:navigated', runInit);
    if (document.readyState !== 'loading') runInit();

    window.RMS.init = runInit;
})();

/* Toast progress animation */
