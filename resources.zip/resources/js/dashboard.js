/* =========================================================
   PROFILE DROPDOWN
   ========================================================= */

function initProfileDropdown() {
    const profileMenu = document.getElementById('profileMenu');
    const profileButton = document.getElementById('profileButton');
    const profileDropdown = document.getElementById('profileDropdown');

    if (!profileMenu || !profileButton || !profileDropdown) {
        return;
    }

    // Hindari event listener terpasang berkali-kali
    if (profileMenu.dataset.profileInitialized === 'true') {
        return;
    }

    profileMenu.dataset.profileInitialized = 'true';

    const openProfile = () => {
        profileMenu.classList.add('is-open');

        profileButton.setAttribute(
            'aria-expanded',
            'true'
        );

        profileDropdown.setAttribute(
            'aria-hidden',
            'false'
        );
    };

    const closeProfile = () => {
        profileMenu.classList.remove('is-open');

        profileButton.setAttribute(
            'aria-expanded',
            'false'
        );

        profileDropdown.setAttribute(
            'aria-hidden',
            'true'
        );
    };

    const toggleProfile = () => {
        const isOpen = profileMenu.classList.contains('is-open');

        if (isOpen) {
            closeProfile();
        } else {
            openProfile();
        }
    };

    /*
     * PROFILE BUTTON
     */
    profileButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();

        toggleProfile();
    });

    /*
     * DROPDOWN
     *
     * Jangan biarkan klik di dalam dropdown
     * dianggap sebagai klik luar.
     */
    profileDropdown.addEventListener('click', (event) => {
        event.stopPropagation();
    });

    /*
     * DOCUMENT CLICK
     */
    document.addEventListener('click', (event) => {
        if (!profileMenu.contains(event.target)) {
            closeProfile();
        }
    });

    /*
     * ESCAPE
     */
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeProfile();
        }
    });

    /*
     * ACCOUNT SETTINGS
     *
     * Untuk sementara belum melakukan navigasi.
     */
    const settingsButton = profileDropdown.querySelector(
        '[data-profile-settings]'
    );

    if (settingsButton) {
        settingsButton.addEventListener('click', (event) => {
            event.preventDefault();

            closeProfile();

            console.log('Pengaturan akun belum diaktifkan.');
        });
    }
}


/* =========================================================
   INITIALIZE
   ========================================================= */

function initDashboardUI() {
    initProfileDropdown();
}


/*
 * Halaman pertama
 */
if (document.readyState === 'loading') {
    document.addEventListener(
        'DOMContentLoaded',
        initDashboardUI,
        { once: true }
    );
} else {
    initDashboardUI();
}


/*
 * Livewire navigation / render
 */
document.addEventListener(
    'livewire:navigated',
    initDashboardUI
);


/*
 * Livewire initialized
 */
document.addEventListener(
    'livewire:init',
    initDashboardUI
);

