<div
    class="rms-store-page rms-store-component"
>
    <div class="rms-store-hero">
        <div class="rms-store-hero-grid"></div>
        <div class="rms-store-hero-glow"></div>
        <span class="rms-store-eyebrow"><i></i> WORKSPACE / STORE MANAGEMENT</span>
        <div class="rms-store-hero-row">
            <div>
                <h1>Store <span>Management.</span></h1>
                <p>Kelola identitas marketplace, brand, logo, dan konfigurasi Store dari satu workspace.</p>
            </div>
            <button type="button" class="rms-store-add" wire:click="openCreate">
                <b>+</b><span><strong>Add Store</strong><small>Connect marketplace</small></span><em>→</em>
            </button>
        </div>
        <div class="rms-store-meta">
            <span><i></i> Workspace active</span><b></b>
            <span>{{ $this->activeStores }} active stores</span>
            <span>{{ $this->totalStores }} total stores</span>
        </div>
    </div>

    <div class="rms-store-kpis">
        <article><span class="rms-kpi-icon red">▣</span><div><small>ACTIVE STORES</small><strong>{{ str_pad((string) $this->activeStores, 2, '0', STR_PAD_LEFT) }}</strong><em>Connected marketplace</em></div><label><i></i>ONLINE</label></article>
        <article><span class="rms-kpi-icon violet">▦</span><div><small>TEMPLATES</small><strong>{{ $this->totalTemplates }}</strong><em>Configured presets</em></div></article>
        <article><span class="rms-kpi-icon dark">⌁</span><div><small>GENERATIONS</small><strong>{{ $this->totalGenerations }}</strong><em>Visuals generated</em></div></article>
        <article><span class="rms-kpi-icon green">✓</span><div><small>CONFIGURATION</small><strong>{{ $this->totalStores > 0 ? '100%' : '0%' }}</strong><em>Workspace readiness</em></div></article>
    </div>

    <div class="rms-store-section-head">
        <div><span>CONNECTED STORES</span><h2>Your marketplace workspace</h2><p>Setiap Store menjadi sumber identitas untuk Template dan AI Generator.</p></div>
        <strong><i></i> {{ str_pad((string) $this->stores->count(), 2, '0', STR_PAD_LEFT) }} RESULTS</strong>
    </div>

    <div class="rms-store-toolbar">
        <label>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
            <input type="text" wire:model.live.debounce.300ms="search" placeholder="Search store, brand, marketplace...">
            <kbd>⌘ K</kbd>
        </label>
        <button type="button" class="{{ $status === 'all' ? 'active' : '' }}" wire:click="setStatus('all')">All <b>⌄</b></button>
        <button type="button" class="{{ $status === 'active' ? 'active' : '' }}" wire:click="setStatus('active')">Active <b>⌄</b></button>
        <button type="button" class="{{ $status === 'inactive' ? 'active' : '' }}" wire:click="setStatus('inactive')">Inactive <b>⌄</b></button>
        <button type="button" wire:click="resetFilters">Reset <b>↺</b></button>
    </div>

    <div class="rms-store-results" wire:key="store-results-{{ $renderVersion }}" wire:loading.class="is-loading" wire:target="search,setStatus,resetFilters,save,delete,toggleStatus">
        @if ($this->stores->isEmpty())
            <div class="rms-store-empty">
                <span>⌕</span>
                <strong>Tidak ada Store ditemukan.</strong>
                <p>Coba ubah pencarian atau filter yang digunakan.</p>
                <button type="button" wire:click="openCreate">Create Store</button>
            </div>
        @else
            <div class="rms-store-grid">
                @foreach ($this->stores as $index => $store)
                    <article class="rms-store-card" style="--card-delay: {{ min($index * 55, 275) }}ms" wire:key="store-card-{{ $store->id }}-{{ $renderVersion }}">
                        <div class="rms-store-cover" style="--store-brand: {{ $store->brand_color ?: '#dc2626' }}">
                            <div class="rms-store-cover-grid"></div>
                            <div class="rms-store-cover-orb"></div>
                            <div class="rms-store-cover-top">
                                <span><i></i>{{ strtoupper($store->marketplace ?: 'MARKETPLACE') }}</span>
                                <div>
                                    <button type="button" wire:click="openEdit({{ $store->id }})" aria-label="Edit Store">✎</button>
                                    <button type="button" wire:click="confirmDelete({{ $store->id }})" aria-label="Delete Store">×</button>
                                </div>
                            </div>
                            <div class="rms-store-logo">
                                <img src="{{ $store->logo_path ? asset('storage/'.$store->logo_path) : asset('images/logo-rizky-moto-shop.png') }}" alt="{{ $store->brand_name ?: $store->name }}">
                            </div>
                        </div>
                        <div class="rms-store-card-body">
                            <div class="rms-store-card-title">
                                <div>
                                    <span class="rms-store-active {{ $store->is_active ? '' : 'is-inactive' }}"><i></i>{{ $store->is_active ? 'ACTIVE' : 'INACTIVE' }}</span>
                                    <h3>{{ $store->name }}</h3>
                                    <p>{{ $store->description ?: ($store->brand_name ?: 'Marketplace identity') }}</p>
                                </div>
                                <b>#{{ str_pad((string) $store->id, 2, '0', STR_PAD_LEFT) }}</b>
                            </div>

                            <div class="rms-store-identity">
                                <span>{{ strtoupper(substr($store->brand_name ?: $store->name, 0, 2)) }}</span>
                                <div><strong>{{ $store->brand_name ?: $store->name }}</strong><small>{{ $store->marketplace ?: 'Marketplace Store' }}</small></div>
                                <em class="{{ $store->is_active ? '' : 'is-offline' }}"><i></i>{{ $store->is_active ? 'Connected' : 'Offline' }}</em>
                            </div>

                            <div class="rms-store-stats">
                                <div><small>Templates</small><strong>{{ $store->templates_count }}</strong></div>
                                <div><small>Generations</small><strong>{{ $store->generations_count }}</strong></div>
                                <div><small>Status</small><strong>{{ $store->is_active ? 'Ready' : 'Paused' }}</strong></div>
                            </div>

                            <div class="rms-store-actions">
                                <button type="button" class="rms-manage-button" wire:click="openEdit({{ $store->id }})"><span>Manage Store</span><span>→</span></button>
                                <button type="button" class="rms-status-action" wire:click="toggleStatus({{ $store->id }})">{{ $store->is_active ? 'Pause' : 'Activate' }}</button>
                            </div>
                        </div>
                    </article>
                @endforeach

                <button type="button" class="rms-store-create" wire:click="openCreate">
                    <span>+</span>
                    <strong>Add New Store</strong>
                    <small>Hubungkan marketplace baru dan siapkan brand identity untuk creative workspace.</small>
                    <em>Create store <b>→</b></em>
                </button>
            </div>
        @endif
    </div>

    @if ($showForm)
        <div class="rms-store-modal-backdrop" wire:click.self="cancelForm">
            <div class="rms-store-modal" wire:key="store-form-{{ $editing ? 'edit-'.$editingId : 'create' }}">
                <div class="rms-store-modal-head">
                    <div>
                        <span>{{ $editing ? 'EDIT STORE' : 'NEW STORE' }}</span>
                        <h2>{{ $editing ? 'Update Store.' : 'Create Store.' }}</h2>
                        <p>{{ $editing ? 'Perbarui identitas marketplace dan konfigurasi Store.' : 'Tambahkan identitas marketplace baru.' }}</p>
                    </div>
                    <button type="button" wire:click="cancelForm">×</button>
                </div>

                <form wire:submit="save">
                    <div class="rms-store-form-grid">
                        <label><span>Store Name *</span><input wire:model="name" type="text" placeholder="Contoh: Rizky Moto Shop">@error('name')<small>{{ $message }}</small>@enderror</label>
                        <label class="rms-marketplace-field"><span>Marketplace *</span>
                            <div class="rms-custom-select" x-data="{ open: false }" @click.outside="open = false">
                                <button type="button" class="rms-custom-select-trigger" @click="open = !open" :aria-expanded="open.toString()">
                                    <span class="rms-marketplace-leading"><i></i><strong>{{ $this->marketplaces[$marketplace] ?? 'Pilih Marketplace' }}</strong></span>
                                    <svg :class="{ 'is-open': open }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m7 10 5 5 5-5"/></svg>
                                </button>
                                <div class="rms-custom-select-menu" x-show="open" x-cloak x-transition:enter="rms-select-enter" x-transition:enter-start="rms-select-enter-start" x-transition:enter-end="rms-select-enter-end" x-transition:leave="rms-select-leave" x-transition:leave-start="rms-select-leave-start" x-transition:leave-end="rms-select-leave-end">
                                    <div class="rms-select-menu-label">MARKETPLACE</div>
                                    @foreach($this->marketplaces as $value => $label)
                                        <button type="button" class="rms-custom-option {{ $marketplace === $value ? 'is-selected' : '' }}" wire:click="setMarketplace('{{ $value }}')" @click="open = false">
                                            <span class="rms-option-mark">{{ strtoupper(substr($label, 0, 1)) }}</span>
                                            <span><strong>{{ $label }}</strong><small>{{ $value === 'other' ? 'Gunakan identitas marketplace lain' : 'Marketplace connected' }}</small></span>
                                            @if($marketplace === $value)<b>✓</b>@endif
                                        </button>
                                    @endforeach
                                </div>
                            </div>
                            @error('marketplace')<small>{{ $message }}</small>@enderror
                        </label>
                        <label><span>Brand Name</span><input wire:model="brand_name" type="text" placeholder="Nama brand yang ditampilkan"></label>
                        <label><span>Brand Color</span><div class="rms-color-field"><input wire:model="brand_color" type="text"><i style="background:{{ $brand_color }}"></i></div>@error('brand_color')<small>{{ $message }}</small>@enderror</label>
                        <label class="full"><span>Description</span><textarea wire:model="description" rows="3" placeholder="Deskripsi singkat Store..."></textarea>@error('description')<small>{{ $message }}</small>@enderror</label>
                        <label><span>Sort Order</span><input wire:model="sort_order" type="number" min="0"></label>
                        <label><span>Status</span><button type="button" class="rms-status-toggle {{ $is_active ? 'on' : '' }}" wire:click="$toggle('is_active')"><i></i>{{ $is_active ? 'Active' : 'Inactive' }}</button></label>
                        <label class="full"><span>Store Logo</span>
                            <div class="rms-logo-upload">
                                <div class="rms-logo-preview">
                                    @if ($logo)<img src="{{ $logo->temporaryUrl() }}" alt="Preview">
                                    @elseif ($currentLogo)<img src="{{ asset('storage/'.$currentLogo) }}" alt="Current logo">
                                    @else<img src="{{ asset('images/logo-rizky-moto-shop.png') }}" alt="Default logo">@endif
                                </div>
                                <div><input wire:model="logo" type="file" accept="image/png,image/jpeg,image/webp"><small>PNG, JPG, WEBP · maksimal 5 MB</small></div>
                            </div>
                            @error('logo')<small>{{ $message }}</small>@enderror
                        </label>
                    </div>
                    <div class="rms-store-modal-actions">
                        <button type="button" class="secondary" wire:click="cancelForm">Batal</button>
                        <button type="submit" class="primary">
                            <span wire:loading.remove wire:target="save">{{ $editing ? 'Simpan Perubahan' : 'Create Store' }}</span>
                            <span wire:loading wire:target="save">Menyimpan...</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif

    @if ($showDelete)
        <div class="rms-store-modal-backdrop rms-delete-backdrop" wire:click.self="cancelDelete">
            <div class="rms-store-confirm rms-delete-modal" wire:key="store-delete-{{ $deleteId ?? 'new' }}">
                <div class="rms-delete-top">
                    <div class="rms-delete-icon"><span>!</span><i></i></div>
                    <button type="button" class="rms-confirm-close" wire:click="cancelDelete" aria-label="Tutup">×</button>
                </div>
                <span class="rms-confirm-eyebrow">REMOVE STORE</span>
                <h2>Hapus <strong>{{ $deleteName }}</strong>?</h2>
                <p class="rms-delete-copy">Tindakan ini akan menghapus identitas Store dari workspace. Pastikan Store memang sudah tidak digunakan.</p>

                <div class="rms-delete-impact">
                    <div><span>Templates</span><strong>{{ $deleteTemplates }}</strong></div>
                    <div><span>Generations</span><strong>{{ $deleteGenerations }}</strong></div>
                    <div><span>Action</span><strong class="danger-text">Permanent</strong></div>
                </div>

                <div class="rms-delete-warning"><span>!</span><p>Jika Store memiliki Template atau Generation, penghapusan akan dibatalkan untuk menjaga data tetap aman.</p></div>

                <div class="rms-store-modal-actions rms-confirm-actions">
                    <button type="button" class="secondary" wire:click="cancelDelete">Batal</button>
                    <button type="button" class="danger" wire:click="delete">
                        <span wire:loading.remove wire:target="delete">Hapus Store</span>
                        <span wire:loading wire:target="delete">Menghapus...</span>
                    </button>
                </div>
            </div>
        </div>
    @endif

    <style>
        /* =========================================================
           STORE LOCAL MOTION SYSTEM
           Nothing here covers the entire dashboard.
           ========================================================= */
        .rms-store-component{position:relative;isolation:isolate;min-width:0}
        .rms-store-results{min-height:180px;transition:opacity .22s ease,transform .22s ease}
        .rms-store-results.is-loading{opacity:.55;transform:translateY(3px);pointer-events:none}
        .rms-store-card{animation:rmsStoreCardIn .42s cubic-bezier(.22,.8,.2,1) both;animation-delay:var(--card-delay,0ms)}
        .rms-store-create{animation:rmsStoreCardIn .42s cubic-bezier(.22,.8,.2,1) both;animation-delay:320ms}
        .rms-store-toolbar{transition:box-shadow .2s ease,border-color .2s ease}
        .rms-store-toolbar:focus-within{border-color:#d4d4d8;box-shadow:0 8px 28px rgba(24,24,27,.05)}
        .rms-store-toolbar button{transition:transform .18s ease,background .18s ease,color .18s ease,border-color .18s ease}
        .rms-store-toolbar button:active{transform:scale(.97)}
        .rms-store-cover-top>div{display:flex;gap:5px}
        .rms-store-cover-top>div button{width:30px;height:30px;border:1px solid rgba(255,255,255,.14);border-radius:9px;color:#fff;background:rgba(255,255,255,.08);cursor:pointer;transition:transform .18s ease,background .18s ease}
        .rms-store-cover-top>div button:hover{background:rgba(255,255,255,.15);transform:translateY(-1px)}
        .rms-store-active.is-inactive{color:#a1a1aa}.rms-store-active.is-inactive i{background:#a1a1aa;box-shadow:none}
        .rms-store-identity em.is-offline{color:#a1a1aa}.rms-store-identity em.is-offline i{background:#a1a1aa;box-shadow:none}

        /* Modal animates only when it is actually created/opened. Internal field clicks do not re-run this animation. */
        .rms-store-modal-backdrop{position:fixed;inset:0;z-index:1300;display:grid;place-items:center;padding:20px;background:rgba(9,9,11,.48);backdrop-filter:blur(8px);animation:rmsStoreBackdropIn .2s ease}
        .rms-store-modal,.rms-store-confirm{width:min(720px,100%);max-height:min(88dvh,760px);overflow:auto;overscroll-behavior:contain;scrollbar-width:none;border:1px solid rgba(255,255,255,.75);border-radius:24px;background:#fff;box-shadow:0 30px 90px rgba(0,0,0,.22);animation:rmsStoreModalIn .26s cubic-bezier(.22,.8,.2,1)}
        .rms-store-modal::-webkit-scrollbar,.rms-store-confirm::-webkit-scrollbar{width:0;height:0}
        .rms-store-modal-head{display:flex;justify-content:space-between;gap:20px;padding:24px;border-bottom:1px solid #f4f4f5}
        .rms-store-modal-head>div>span,.rms-store-confirm>span{color:#dc2626;font-size:8px;font-weight:900;letter-spacing:.16em}
        .rms-store-modal-head h2,.rms-store-confirm h2{margin:7px 0 4px;font-size:27px;letter-spacing:-.04em}
        .rms-store-modal-head p,.rms-store-confirm p{margin:0;color:#a1a1aa;font-size:11px;line-height:1.6}
        .rms-store-modal-head>button{width:36px;height:36px;flex:0 0 36px;border:1px solid #e4e4e7;border-radius:10px;background:#fff;color:#71717a;font-size:20px;cursor:pointer;transition:transform .18s ease,background .18s ease}
        .rms-store-modal-head>button:hover{background:#fafafa;transform:rotate(4deg)}
        .rms-store-modal form{padding:22px}
        .rms-store-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}
        .rms-store-form-grid label{display:grid;gap:7px;min-width:0}
        .rms-store-form-grid label.full{grid-column:1/-1}
        .rms-store-form-grid label>span{font-size:10px;font-weight:900;color:#52525b}
        .rms-store-form-grid input,.rms-store-form-grid textarea{width:100%;border:1px solid #e4e4e7;border-radius:11px;padding:11px 12px;outline:0;background:#fafafa;color:#27272a;font:inherit;font-size:12px;transition:border-color .18s ease,box-shadow .18s ease}
        .rms-store-form-grid input:focus,.rms-store-form-grid textarea:focus{border-color:#a1a1aa;box-shadow:0 0 0 3px rgba(24,24,27,.04)}
        .rms-store-form-grid textarea{resize:vertical;min-height:92px}.rms-store-form-grid label>small{color:#dc2626;font-size:9px}
        .rms-color-field{position:relative}.rms-color-field>input{padding-right:45px}.rms-color-field>i{position:absolute;right:11px;top:50%;width:20px;height:20px;border:1px solid #e4e4e7;border-radius:7px;transform:translateY(-50%)}
        .rms-status-toggle{display:flex;align-items:center;gap:8px;width:max-content;padding:9px 12px;border:1px solid #e4e4e7;border-radius:10px;background:#fafafa;font-size:11px;font-weight:800;cursor:pointer;transition:.18s ease}
        .rms-status-toggle i{width:26px;height:15px;border-radius:999px;background:#d4d4d8;position:relative}.rms-status-toggle i:after{content:"";position:absolute;top:2px;left:2px;width:11px;height:11px;border-radius:50%;background:#fff;transition:.2s}.rms-status-toggle.on{color:#16a34a;border-color:#bbf7d0;background:#f0fdf4}.rms-status-toggle.on i{background:#22c55e}.rms-status-toggle.on i:after{left:13px}
        .rms-logo-upload{display:flex;align-items:center;gap:14px;padding:12px;border:1px dashed #d4d4d8;border-radius:13px;background:#fafafa}.rms-logo-preview{display:grid;width:64px;height:64px;flex:0 0 64px;place-items:center;overflow:hidden;border:1px solid #e4e4e7;border-radius:13px;background:#18181b}.rms-logo-preview img{width:90%;height:90%;object-fit:contain}.rms-logo-upload input{max-width:100%;font-size:11px}.rms-logo-upload small{display:block;margin-top:5px;color:#a1a1aa;font-size:9px}
        .rms-store-modal-actions{display:flex;justify-content:flex-end;gap:8px;padding:16px 22px;border-top:1px solid #f4f4f5}.rms-store-modal-actions button{height:40px;padding:0 15px;border-radius:10px;font-size:10px;font-weight:900;cursor:pointer;transition:transform .18s ease,opacity .18s ease}.rms-store-modal-actions button:hover{transform:translateY(-1px)}.rms-store-modal-actions .secondary{border:1px solid #e4e4e7;background:#fff;color:#52525b}.rms-store-modal-actions .primary{border:0;background:#18181b;color:#fff}.rms-store-modal-actions .danger{border:0;background:#dc2626;color:#fff}
        .rms-store-confirm{width:min(430px,100%);padding:26px}.danger-icon{display:grid;width:46px;height:46px;place-items:center;margin-bottom:14px;border-radius:14px;color:#dc2626;background:#fef2f2;font-size:19px;font-weight:950}
        .rms-store-empty{animation:rmsStoreCardIn .35s ease both}

        /* Hide scrollbar, preserve scrolling everywhere inside Store. */
        .rms-store-component,.rms-store-component *{scrollbar-width:none}.rms-store-component *::-webkit-scrollbar{width:0;height:0}
        

        @keyframes rmsStoreCardIn{from{opacity:0;transform:translateY(10px) scale(.992)}to{opacity:1;transform:none}}
        @keyframes rmsStoreBackdropIn{from{opacity:0}to{opacity:1}}
        @keyframes rmsStoreModalIn{from{opacity:0;transform:translateY(14px) scale(.975)}to{opacity:1;transform:none}}

        @media(max-width:900px){
            .rms-store-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}
            .rms-store-grid{grid-template-columns:1fr}
        }
        @media(max-width:700px){
            .rms-store-page{width:100%;min-width:0}
            .rms-store-hero-row{flex-direction:column;align-items:stretch}
            .rms-store-add{width:100%}
            .rms-store-kpis{grid-template-columns:1fr 1fr;gap:10px}
            .rms-store-toolbar{display:flex;overflow-x:auto;overscroll-behavior-x:contain;padding:7px}
            .rms-store-toolbar label{min-width:calc(100vw - 30px);flex:0 0 calc(100vw - 30px)}
            .rms-store-toolbar button{flex:0 0 auto;white-space:nowrap}
            .rms-store-modal-backdrop{padding:8px;align-items:end}
            .rms-store-modal{width:100%;max-height:92dvh;border-radius:22px 22px 16px 16px}
            .rms-store-modal-head{padding:18px 16px 15px}.rms-store-modal-head h2{font-size:24px}
            .rms-store-modal form{padding:16px}.rms-store-form-grid{grid-template-columns:1fr;gap:12px}.rms-store-form-grid label.full{grid-column:auto}
            .rms-logo-upload{align-items:flex-start;flex-direction:column}.rms-logo-preview{width:60px;height:60px;flex-basis:60px}
            .rms-store-modal-actions{padding:12px 16px;position:sticky;bottom:0;background:rgba(255,255,255,.94);backdrop-filter:blur(8px)}
            .rms-store-modal-actions button{flex:1}.rms-store-confirm{width:100%;padding:22px;border-radius:20px}
        }
        @media(max-width:430px){
            .rms-store-kpis{grid-template-columns:1fr}
            .rms-store-card-body{padding:15px}.rms-store-card-title h3{font-size:20px}
            .rms-store-actions{gap:7px}.rms-store-actions button:first-child{flex:1}.rms-store-actions button:last-child{flex:0 0 auto}
            .rms-store-modal-backdrop{padding:6px}.rms-store-modal{max-height:94dvh}
        }

        /* =========================================================
           V4 STORE CARDS / CUSTOM MARKETPLACE / DELETE DIALOG
           ========================================================= */
        .rms-store-card{border:1px solid #e4e4e7;border-radius:24px;background:#fff;box-shadow:0 12px 32px rgba(24,24,27,.055);overflow:hidden;transition:transform .28s ease,box-shadow .28s ease,border-color .28s ease}
        .rms-store-card:hover{transform:translateY(-4px);border-color:#d4d4d8;box-shadow:0 22px 48px rgba(24,24,27,.1)}
        .rms-store-card-body{padding:20px 20px 18px}
        .rms-store-card-title{gap:12px}.rms-store-card-title>div{min-width:0}.rms-store-card-title h3{font-size:22px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.rms-store-card-title p{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
        .rms-store-actions{display:grid;grid-template-columns:minmax(0,1fr) 82px;gap:8px;align-items:stretch;margin-top:12px}.rms-store-actions button{min-width:0;height:42px;border-radius:11px;font-size:10px;font-weight:900;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.rms-manage-button{display:flex!important;align-items:center;justify-content:space-between;padding:0 13px;border:0;background:#18181b;color:#fff;transition:background .2s ease,transform .2s ease}.rms-manage-button:hover{background:#27272a;transform:translateY(-1px)}.rms-manage-button span:last-child{font-size:14px;flex:0 0 auto;margin-left:8px}.rms-status-action{padding:0 8px;border:1px solid #e4e4e7;background:#fff;color:#71717a;transition:background .2s ease,color .2s ease,border-color .2s ease}.rms-status-action:hover{background:#fafafa;border-color:#d4d4d8;color:#18181b}
        .rms-custom-select{position:relative;z-index:30}.rms-custom-select-trigger{display:flex;width:100%;min-height:44px;align-items:center;justify-content:space-between;gap:10px;padding:0 12px;border:1px solid #e4e4e7;border-radius:11px;background:#fafafa;color:#27272a;cursor:pointer;transition:border-color .18s ease,box-shadow .18s ease,background .18s ease}.rms-custom-select-trigger:hover,.rms-custom-select:focus-within .rms-custom-select-trigger{border-color:#c4c4c9;background:#fff;box-shadow:0 0 0 3px rgba(24,24,27,.035)}.rms-marketplace-leading{display:flex;min-width:0;align-items:center;gap:9px}.rms-marketplace-leading i{width:8px;height:8px;flex:0 0 8px;border-radius:50%;background:#dc2626;box-shadow:0 0 0 4px rgba(220,38,38,.08)}.rms-marketplace-leading strong{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rms-custom-select-trigger svg{width:16px;height:16px;flex:0 0 16px;color:#71717a;transition:transform .2s ease}.rms-custom-select-trigger svg.is-open{transform:rotate(180deg)}.rms-custom-select-menu{position:absolute;left:0;right:0;top:calc(100% + 7px);z-index:80;overflow:hidden;padding:7px;border:1px solid #e4e4e7;border-radius:15px;background:rgba(255,255,255,.98);box-shadow:0 24px 60px rgba(24,24,27,.15);backdrop-filter:blur(14px);transform-origin:top}.rms-select-menu-label{padding:7px 9px 6px;color:#a1a1aa;font-size:8px;font-weight:900;letter-spacing:.15em}.rms-custom-option{display:grid;width:100%;grid-template-columns:30px minmax(0,1fr) 18px;align-items:center;gap:9px;padding:8px;border:0;border-radius:10px;background:transparent;text-align:left;cursor:pointer;transition:background .16s ease,transform .16s ease}.rms-custom-option:hover{background:#f4f4f5;transform:translateX(2px)}.rms-custom-option.is-selected{background:#fafafa}.rms-option-mark{display:grid;width:30px;height:30px;place-items:center;border-radius:9px;background:#18181b;color:#fff;font-size:9px;font-weight:900}.rms-custom-option:nth-child(odd) .rms-option-mark{background:#27272a}.rms-custom-option span:nth-child(2){min-width:0}.rms-custom-option strong,.rms-custom-option small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rms-custom-option strong{font-size:10px;color:#27272a}.rms-custom-option small{margin-top:2px;color:#a1a1aa;font-size:8px}.rms-custom-option>b{color:#16a34a;font-size:13px}.rms-select-enter{transition:opacity .16s ease,transform .16s ease}.rms-select-enter-start{opacity:0;transform:translateY(-5px) scale(.98)}.rms-select-enter-end{opacity:1;transform:none}.rms-select-leave{transition:opacity .12s ease,transform .12s ease}.rms-select-leave-start{opacity:1}.rms-select-leave-end{opacity:0;transform:translateY(-4px) scale(.98)}
        .rms-store-modal-backdrop{position:absolute!important;inset:0!important;z-index:200!important;display:grid;place-items:center;overflow:auto!important;padding:28px!important;background:rgba(9,9,11,.5);backdrop-filter:blur(8px);overscroll-behavior:contain;animation:rmsStoreBackdropIn .2s ease}.rms-store-modal,.rms-store-confirm{max-height:min(86vh,760px)!important;overflow-y:auto!important;overflow-x:hidden!important}.rms-delete-backdrop{align-items:center}.rms-delete-modal{width:min(500px,calc(100% - 28px))!important;padding:24px!important;border-radius:24px!important}.rms-delete-top{display:flex;align-items:flex-start;justify-content:space-between}.rms-delete-icon{position:relative;display:grid;width:54px;height:54px;place-items:center;border:1px solid #fecaca;border-radius:17px;background:linear-gradient(145deg,#fff1f2,#fef2f2);color:#dc2626;box-shadow:0 10px 25px rgba(220,38,38,.12);overflow:hidden}.rms-delete-icon span{position:relative;z-index:2;font-size:22px;font-weight:950}.rms-delete-icon i{position:absolute;width:70px;height:70px;border-radius:50%;background:rgba(220,38,38,.1);filter:blur(8px);animation:rmsDeletePulse 2s ease-in-out infinite}.rms-confirm-close{width:34px;height:34px;border:1px solid #e4e4e7;border-radius:10px;background:#fff;color:#71717a;font-size:18px;cursor:pointer;transition:.18s ease}.rms-confirm-close:hover{background:#f4f4f5;color:#18181b;transform:rotate(4deg)}.rms-confirm-eyebrow{display:block;margin-top:18px;color:#dc2626;font-size:8px;font-weight:950;letter-spacing:.18em}.rms-delete-modal h2{margin:7px 0 7px;font-size:27px;letter-spacing:-.04em;line-height:1.15}.rms-delete-modal h2 strong{color:#dc2626}.rms-delete-copy{margin:0!important;color:#71717a!important;font-size:11px!important;line-height:1.6!important}.rms-delete-impact{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:18px}.rms-delete-impact div{padding:11px;border:1px solid #f0f0f2;border-radius:12px;background:#fafafa}.rms-delete-impact span,.rms-delete-impact strong{display:block}.rms-delete-impact span{font-size:8px;color:#a1a1aa;text-transform:uppercase;letter-spacing:.08em}.rms-delete-impact strong{margin-top:5px;font-size:12px;color:#27272a}.rms-delete-impact .danger-text{color:#dc2626}.rms-delete-warning{display:flex;gap:9px;margin-top:12px;padding:11px;border:1px solid #fee2e2;border-radius:12px;background:#fff7f7}.rms-delete-warning>span{display:grid;width:20px;height:20px;flex:0 0 20px;place-items:center;border-radius:7px;background:#dc2626;color:#fff;font-size:10px;font-weight:900}.rms-delete-warning p{margin:0;color:#7f1d1d;font-size:9px;line-height:1.55}.rms-confirm-actions{margin:20px -24px -24px;padding:15px 24px;background:#fafafa;border-radius:0 0 24px 24px}.rms-confirm-actions .danger{min-width:112px}.rms-confirm-actions .secondary{min-width:82px}
        @keyframes rmsDeletePulse{0%,100%{transform:scale(.75);opacity:.4}50%{transform:scale(1.25);opacity:.8}}
        @media(max-width:700px){.rms-store-modal-backdrop{padding:12px!important;align-items:flex-end!important}.rms-store-modal{width:100%!important;max-height:88vh!important;border-radius:22px 22px 16px 16px!important}.rms-delete-modal{width:100%!important;max-height:none!important;padding:20px!important;border-radius:22px!important}.rms-delete-impact{grid-template-columns:1fr 1fr}.rms-delete-impact div:last-child{grid-column:1/-1}.rms-confirm-actions{margin:18px -20px -20px;padding:13px 20px;border-radius:0 0 22px 22px}.rms-store-actions{grid-template-columns:minmax(0,1fr) 86px}.rms-manage-button{padding:0 11px}.rms-store-card-title h3{font-size:20px}.rms-custom-select-menu{max-height:280px;overflow-y:auto}.rms-store-modal-backdrop{touch-action:auto}.rms-store-modal,.rms-store-confirm{touch-action:pan-y!important;-webkit-overflow-scrolling:touch}}
        @media(max-width:430px){.rms-store-actions{grid-template-columns:1fr}.rms-status-action{height:38px!important}.rms-store-card-body{padding:16px}.rms-delete-impact{grid-template-columns:1fr 1fr}.rms-delete-modal h2{font-size:24px}.rms-confirm-actions{flex-direction:column-reverse}.rms-confirm-actions button{width:100%}}

        @media(prefers-reduced-motion:reduce){.rms-store-card,.rms-store-create,.rms-store-empty,.rms-store-modal,.rms-store-confirm,.rms-store-modal-backdrop{animation:none}.rms-store-results{transition:none}}

        /* =========================================================
           MODAL / SHEET SCROLL FIX
           Teleported to <body> so no transformed dashboard ancestor
           can clip the fixed overlay. Only the modal itself scrolls.
           ========================================================= */
        .rms-store-modal-backdrop{position:fixed!important;inset:0!important;overflow:hidden!important;overscroll-behavior:none!important;touch-action:none!important}
        .rms-store-modal,.rms-store-confirm{position:relative;touch-action:pan-y!important;overscroll-behavior:contain!important;-webkit-overflow-scrolling:touch!important;overflow-x:hidden!important;overflow-y:auto!important;max-height:calc(100dvh - 32px)!important}
        .rms-store-modal form{min-height:0}
        @media(max-width:700px){
            .rms-store-modal-backdrop{padding:7px!important;align-items:flex-end!important}
            .rms-store-modal{width:100%!important;max-height:calc(100dvh - 14px)!important;border-radius:23px 23px 15px 15px!important}
            .rms-store-modal-head{position:sticky;top:0;z-index:3;background:rgba(255,255,255,.96);backdrop-filter:blur(12px)}
            .rms-store-modal-actions{position:sticky!important;bottom:0!important;z-index:3}
            .rms-store-confirm{width:100%!important;max-height:calc(100dvh - 28px)!important}
        }
    </style>
</div>
