<?php

namespace App\Services;

use App\Models\GeneratedImage;
use App\Models\Generation;
use App\Models\Store;
use App\Models\Template;
use App\Models\User;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use RuntimeException;
use Throwable;

class OpenAiImageService
{
    private const BASE_URL = 'https://api.openai.com/v1';

    public function generate(
        User $user,
        Store $store,
        Template $template,
        $imageOne,
        $imageTwo,
        string $model,
        string $aspectRatio,
        string $quality,
        int $imageCount = 1,
    ): Generation {
        set_time_limit(300);
        ini_set('max_execution_time', '300');

        $startedAt = microtime(true);
        $httpErrorLogged = false;

        $this->activity()->processing(
            action: 'generate_openai_image',
            category: 'generator',
            title: 'Generate AI image dimulai.',
            description: 'Generator menerima request dan mulai menyiapkan input untuk OpenAI.',
            metadata: [
                'source' => 'dashboard_generator',
                'store_id' => $store->id,
                'template_id' => $template->id,
                'model' => $model ?: null,
                'aspect_ratio' => $aspectRatio,
                'quality' => $quality,
                'requested_image_count' => $imageCount,
                'use_installed_reference' => (bool) $imageTwo,
            ],
        );

        $settings = \App\Models\OpenAiSetting::query()->first();
        $apiKey = $settings?->api_key;

        if (! filled($apiKey)) {
            $message = 'API Key OpenAI belum tersimpan. Buka Settings → OpenAI API.';

            $this->activity()->error(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generate AI image gagal.',
                description: $message,
                metadata: [
                    'source' => 'openai_image_service',
                    'reason' => 'missing_api_key',
                ],
                durationMs: $this->durationMs($startedAt),
            );

            throw new RuntimeException($message);
        }

        $model = trim($model);

        if ($model === '') {
            $message = 'Model OpenAI belum dipilih.';

            $this->activity()->error(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generate AI image gagal.',
                description: $message,
                metadata: [
                    'source' => 'openai_image_service',
                    'reason' => 'missing_model',
                ],
                durationMs: $this->durationMs($startedAt),
            );

            throw new RuntimeException($message);
        }

        $prompt = $this->buildPrompt($store, $template, $imageTwo !== null);
        $negativePrompt = trim((string) ($template->negative_prompt ?? ''));

        $generation = Generation::query()->create([
            'user_id' => $user->id,
            'store_id' => $store->id,
            'template_id' => $template->id,
            'product_image_1_path' => null,
            'product_image_2_path' => null,
            'reference_image_path' => $template->example_image_path,
            'prompt' => $prompt,
            'negative_prompt' => $negativePrompt ?: null,
            'aspect_ratio' => $aspectRatio,
            'output_quality' => $quality,
            'model' => $model,
            'status' => 'processing',
            'metadata' => [
                'source' => 'dashboard_generator',
                'template_id' => $template->id,
                'store_id' => $store->id,
                'requested_image_count' => $imageCount,
                'use_installed_reference' => (bool) $imageTwo,
            ],
            'started_at' => now(),
        ]);

        $this->activity()->processing(
            action: 'generate_openai_image',
            category: 'generator',
            title: 'Input generate sedang diproses.',
            description: 'Generation record #' . $generation->id . ' dibuat. File produk sedang disiapkan.',
            metadata: [
                'source' => 'openai_image_service',
                'generation_id' => $generation->id,
                'store_id' => $store->id,
                'template_id' => $template->id,
                'model' => $model,
            ],
        );

        try {
            $productOnePath = $imageOne->getRealPath();
            $productTwoPath = $imageTwo?->getRealPath();

            if (! $productOnePath || ! is_readable($productOnePath)) {
                throw new RuntimeException('Gambar utama tidak dapat dibaca oleh server.');
            }

            if ($imageTwo && (! $productTwoPath || ! is_readable($productTwoPath))) {
                throw new RuntimeException('Foto referensi pemasangan tidak dapat dibaca oleh server.');
            }

            $sourceOne = $imageOne->store('generations/source', 'public');
            $sourceTwo = $imageTwo ? $imageTwo->store('generations/source', 'public') : null;

            if (! $sourceOne || ($imageTwo && ! $sourceTwo)) {
                throw new RuntimeException('File gambar input gagal disimpan ke storage server.');
            }

            $generation->update([
                'product_image_1_path' => $sourceOne,
                'product_image_2_path' => $sourceTwo,
            ]);

            $attachments = [
                [$productOnePath, basename($productOnePath)],
            ];

            if ($imageTwo && $productTwoPath) {
                $attachments[] = [$productTwoPath, basename($productTwoPath)];
            }

            if ($store->logo_path && Storage::disk('public')->exists($store->logo_path)) {
                $logoPath = Storage::disk('public')->path($store->logo_path);

                if (is_readable($logoPath)) {
                    $attachments[] = [$logoPath, basename($logoPath)];
                }
            }

            $this->activity()->processing(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Mengirim request ke OpenAI.',
                description: sprintf(
                    'POST /v1/images/edits dengan %d attachment, model %s.',
                    count($attachments),
                    $model
                ),
                metadata: [
                    'source' => 'openai_image_service',
                    'generation_id' => $generation->id,
                    'endpoint' => '/v1/images/edits',
                    'attachment_count' => count($attachments),
                    'model' => $model,
                    'size' => $this->mapSize($aspectRatio),
                    'quality' => $this->mapQuality($quality),
                    'image_count' => $imageCount,
                ],
            );

            $request = Http::acceptJson()
                ->withToken($apiKey)
                ->connectTimeout(15)
                ->timeout(240);

            $handles = [];

            try {
                foreach ($attachments as [$path, $filename]) {
                    $handle = fopen($path, 'rb');

                    if ($handle === false) {
                        throw new RuntimeException('File input tidak dapat dibuka: ' . $filename);
                    }

                    $handles[] = $handle;
                    $request = $request->attach('image[]', $handle, $filename);
                }

                $payload = [
                    'model' => $model,
                    'prompt' => $prompt,
                    'n' => max(1, min(4, $imageCount)),
                    'size' => $this->mapSize($aspectRatio),
                    'quality' => $this->mapQuality($quality),
                    'output_format' => 'png',
                ];

                if ($negativePrompt !== '') {
                    $payload['prompt'] .= "\n\nAvoid: " . $negativePrompt;
                }

                $response = $request->post(self::BASE_URL . '/images/edits', $payload);
            } finally {
                foreach ($handles as $handle) {
                    if (is_resource($handle)) {
                        fclose($handle);
                    }
                }
            }

            $durationMs = $this->durationMs($startedAt);

            if (! $response->successful()) {
                $error = $this->extractError($response);

                $this->activity()->error(
                    action: 'generate_openai_image',
                    category: 'generator',
                    title: 'OpenAI image generation gagal.',
                    description: $error,
                    metadata: [
                        'source' => 'openai_image_service',
                        'generation_id' => $generation->id,
                        'endpoint' => '/v1/images/edits',
                        'model' => $model,
                        'response_body' => $this->safeResponseBody($response),
                    ],
                    durationMs: $durationMs,
                    httpStatus: $response->status(),
                );

                $httpErrorLogged = true;
                throw new RuntimeException($error);
            }

            $data = $response->json('data', []);

            if (! is_array($data) || $data === []) {
                throw new RuntimeException('OpenAI tidak mengembalikan gambar.');
            }

            $this->activity()->processing(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Response OpenAI diterima.',
                description: sprintf(
                    'OpenAI mengembalikan %d item image. Server mulai menyimpan hasil.',
                    count($data)
                ),
                metadata: [
                    'source' => 'openai_image_service',
                    'generation_id' => $generation->id,
                    'model' => $model,
                    'response_items' => count($data),
                ],
                durationMs: $durationMs,
                httpStatus: $response->status(),
            );

            $saved = 0;

            foreach ($data as $index => $item) {
                try {
                    $binary = $this->resolveImageBinary($item);
                } catch (Throwable $e) {
                    $this->activity()->error(
                        action: 'generate_openai_image',
                        category: 'generator',
                        title: 'Hasil image gagal diambil.',
                        description: $e->getMessage(),
                        metadata: [
                            'source' => 'openai_image_service',
                            'generation_id' => $generation->id,
                            'openai_index' => $index,
                        ],
                        durationMs: $this->durationMs($startedAt),
                    );

                    throw $e;
                }

                if ($binary === null || $binary === '') {
                    throw new RuntimeException(
                        'OpenAI mengembalikan item image #' . ($index + 1) . ' tanpa binary image yang dapat dibaca.'
                    );
                }

                $filename = 'generation-' . $generation->id . '-' . ($index + 1) . '-' . uniqid() . '.png';
                $path = 'generations/output/' . now()->format('Y/m') . '/' . $filename;

                Storage::disk('public')->put($path, $binary);
                [$width, $height] = $this->imageDimensions(Storage::disk('public')->path($path));

                GeneratedImage::query()->create([
                    'generation_id' => $generation->id,
                    'image_path' => $path,
                    'image_url' => Storage::disk('public')->url($path),
                    'model' => $model,
                    'format' => 'png',
                    'width' => $width,
                    'height' => $height,
                    'metadata' => [
                        'openai_index' => $index,
                        'source' => 'images/edits',
                        'size' => $this->mapSize($aspectRatio),
                        'quality' => $this->mapQuality($quality),
                        'stored_at' => now()->toIso8601String(),
                    ],
                    'is_primary' => $saved === 0,
                    'is_favorite' => false,
                ]);

                $saved++;

                $this->activity()->processing(
                    action: 'generate_openai_image',
                    category: 'generator',
                    title: 'Hasil image tersimpan.',
                    description: sprintf(
                        'Image %d/%d berhasil disimpan ke storage.',
                        $saved,
                        count($data)
                    ),
                    metadata: [
                        'source' => 'openai_image_service',
                        'generation_id' => $generation->id,
                        'image_index' => $index,
                        'format' => 'png',
                        'width' => $width,
                        'height' => $height,
                        'path' => $path,
                    ],
                );
            }

            if ($saved === 0) {
                throw new RuntimeException(
                    'OpenAI mengembalikan response tanpa binary image yang dapat disimpan.'
                );
            }

            $generation->update([
                'status' => 'completed',
                'completed_at' => now(),
                'metadata' => array_merge($generation->metadata ?? [], [
                    'saved_images' => $saved,
                    'completed_at' => now()->toIso8601String(),
                ]),
            ]);

            $this->activity()->success(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generate AI image berhasil.',
                description: sprintf(
                    '%d gambar berhasil dibuat dan disimpan. Generation #%d.',
                    $saved,
                    $generation->id
                ),
                metadata: [
                    'source' => 'openai_image_service',
                    'generation_id' => $generation->id,
                    'store_id' => $store->id,
                    'template_id' => $template->id,
                    'store_logo_path' => $store->logo_path,
                    'model' => $model,
                    'saved_images' => $saved,
                    'aspect_ratio' => $aspectRatio,
                    'quality' => $quality,
                ],
                durationMs: $this->durationMs($startedAt),
                httpStatus: $response->status(),
            );

            return $generation->fresh(['generatedImages', 'store', 'template']);
        } catch (Throwable $e) {
            $generation->update([
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);

            /*
             * Some errors (for example API errors above) have already been
             * logged with richer HTTP metadata. We still emit one generic
             * failure event only when the exception did not come from the
             * explicit HTTP error branch.
             */
            if (! $httpErrorLogged) {
                $this->activity()->error(
                    action: 'generate_openai_image',
                    category: 'generator',
                    title: 'Generate AI image gagal.',
                    description: $e->getMessage(),
                    metadata: [
                        'source' => 'openai_image_service',
                        'generation_id' => $generation->id,
                        'model' => $model,
                        'exception' => get_class($e),
                    ],
                    durationMs: $this->durationMs($startedAt),
                );
            }

            throw $e;
        }
    }

    /**
     * Store the uploaded assets and create a queued generation record.
     * The expensive OpenAI call is deliberately not performed in the Livewire request.
     */
    public function queueGeneration(
        User $user,
        Store $store,
        Template $template,
        $imageOne,
        $imageTwo,
        string $model,
        string $aspectRatio,
        string $quality,
        int $imageCount = 1,
    ): Generation {
        $startedAt = microtime(true);
        $settings = \App\Models\OpenAiSetting::query()->first();
        $apiKey = $settings?->api_key;

        if (! filled($apiKey)) {
            throw new RuntimeException('API Key OpenAI belum tersimpan. Buka Settings → OpenAI API.');
        }

        $model = trim($model);
        if ($model === '') {
            throw new RuntimeException('Model OpenAI belum dipilih.');
        }

        $sourceOne = $imageOne->store('generations/source', 'public');
        $sourceTwo = $imageTwo ? $imageTwo->store('generations/source', 'public') : null;

        if (! $sourceOne || ($imageTwo && ! $sourceTwo)) {
            throw new RuntimeException('File gambar input gagal disimpan ke storage server.');
        }

        $hasInstalledReference = (bool) $imageTwo;
        $prompt = $this->buildPrompt($store, $template, $hasInstalledReference);
        $negativePrompt = trim((string) ($template->negative_prompt ?? ''));

        $generation = Generation::query()->create([
            'user_id' => $user->id,
            'store_id' => $store->id,
            'template_id' => $template->id,
            'product_image_1_path' => $sourceOne,
            'product_image_2_path' => $sourceTwo,
            'reference_image_path' => $template->example_image_path,
            'prompt' => $prompt,
            'negative_prompt' => $negativePrompt ?: null,
            'aspect_ratio' => $aspectRatio,
            'output_quality' => $quality,
            'model' => $model,
            'status' => 'queued',
            'metadata' => [
                'source' => 'dashboard_generator',
                'template_id' => $template->id,
                'store_id' => $store->id,
                'requested_image_count' => $imageCount,
                'use_installed_reference' => $hasInstalledReference,
                'reference_count' => $hasInstalledReference ? 3 : 2,
                'progress' => 4,
                'progress_stage' => 'Menunggu worker queue',
                'queued_at' => now()->toIso8601String(),
            ],
        ]);

        $this->activity()->processing(
            action: 'generate_openai_image',
            category: 'generator',
            title: 'Generate AI image masuk antrean.',
            description: sprintf(
                'Generation #%d siap diproses di background. %d reference image akan digunakan.',
                $generation->id,
                $hasInstalledReference ? 3 : 2
            ),
            metadata: [
                'source' => 'generator_queue',
                'generation_id' => $generation->id,
                'store_id' => $store->id,
                'template_id' => $template->id,
                'model' => $model,
                'reference_count' => $hasInstalledReference ? 3 : 2,
            ],
            durationMs: $this->durationMs($startedAt),
        );

        return $generation->fresh(['store', 'template', 'generatedImages']);
    }

    /**
     * Process a previously queued generation from a queue worker.
     */
    public function processQueuedGeneration(Generation $generation): Generation
    {
        set_time_limit(300);
        ini_set('max_execution_time', '300');

        $generation->loadMissing(['store', 'template']);
        $store = $generation->store;
        $template = $generation->template;
        $startedAt = microtime(true);
        $httpErrorLogged = false;

        $generation->update([
            'status' => 'processing',
            'started_at' => now(),
            'metadata' => array_merge($generation->metadata ?? [], [
                'progress' => 10,
                'progress_stage' => 'Menyiapkan input',
                'started_at' => now()->toIso8601String(),
            ]),
        ]);

        $this->activity()->processing(
            action: 'generate_openai_image',
            category: 'generator',
            title: 'Background generation dimulai.',
            description: 'Worker mulai memproses Generation #' . $generation->id . '.',
            metadata: [
                'source' => 'openai_image_queue',
                'generation_id' => $generation->id,
                'store_id' => $store?->id,
                'template_id' => $template?->id,
            ],
        );

        try {
            if (! $store || ! $template) {
                throw new RuntimeException('Store atau Template generation tidak ditemukan.');
            }

            $settings = \App\Models\OpenAiSetting::query()->first();
            $apiKey = $settings?->api_key;
            if (! filled($apiKey)) {
                throw new RuntimeException('API Key OpenAI belum tersimpan.');
            }

            $model = trim((string) $generation->model);
            if ($model === '') {
                throw new RuntimeException('Model OpenAI belum dipilih.');
            }

            $productOnePath = Storage::disk('public')->path($generation->product_image_1_path);
            $productTwoPath = $generation->product_image_2_path
                ? Storage::disk('public')->path($generation->product_image_2_path)
                : null;

            if (! is_readable($productOnePath)) {
                throw new RuntimeException('Gambar utama tidak dapat dibaca dari storage.');
            }
            if ($productTwoPath && ! is_readable($productTwoPath)) {
                throw new RuntimeException('Foto referensi pemasangan tidak dapat dibaca dari storage.');
            }

            $generation->update(['metadata' => array_merge($generation->metadata ?? [], [
                'progress' => 25,
                'progress_stage' => 'Menyiapkan reference image',
            ])]);

            $attachments = [[$productOnePath, basename($productOnePath)]];
            if ($productTwoPath) {
                $attachments[] = [$productTwoPath, basename($productTwoPath)];
            }

            if ($store->logo_path && Storage::disk('public')->exists($store->logo_path)) {
                $logoPath = Storage::disk('public')->path($store->logo_path);
                if (is_readable($logoPath)) {
                    $attachments[] = [$logoPath, basename($logoPath)];
                }
            }

            $generation->update(['metadata' => array_merge($generation->metadata ?? [], [
                'progress' => 35,
                'progress_stage' => 'Mengirim request ke OpenAI',
                'attachment_count' => count($attachments),
            ])]);

            $this->activity()->processing(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Mengirim request ke OpenAI.',
                description: sprintf('POST /v1/images/edits dengan %d attachment, model %s.', count($attachments), $model),
                metadata: [
                    'source' => 'openai_image_queue',
                    'generation_id' => $generation->id,
                    'endpoint' => '/v1/images/edits',
                    'attachment_count' => count($attachments),
                    'model' => $model,
                    'image_count' => (int) (($generation->metadata ?? [])['requested_image_count'] ?? 1),
                ],
            );

            $request = Http::acceptJson()->withToken($apiKey)->connectTimeout(15)->timeout(240);
            $handles = [];
            try {
                foreach ($attachments as [$path, $filename]) {
                    $handle = fopen($path, 'rb');
                    if ($handle === false) {
                        throw new RuntimeException('File input tidak dapat dibuka: ' . $filename);
                    }
                    $handles[] = $handle;
                    $request = $request->attach('image[]', $handle, $filename);
                }

                $payload = [
                    'model' => $model,
                    'prompt' => (string) $generation->prompt,
                    'n' => max(1, min(4, (int) (($generation->metadata ?? [])['requested_image_count'] ?? 1))),
                    'size' => $this->mapSize((string) $generation->aspect_ratio),
                    'quality' => $this->mapQuality((string) $generation->output_quality),
                    'output_format' => 'png',
                ];
                if (filled($generation->negative_prompt)) {
                    $payload['prompt'] .= "\n\nAvoid: " . $generation->negative_prompt;
                }
                $response = $request->post(self::BASE_URL . '/images/edits', $payload);
            } finally {
                foreach ($handles as $handle) {
                    if (is_resource($handle)) fclose($handle);
                }
            }

            if (! $response->successful()) {
                $error = $this->extractError($response);
                $httpErrorLogged = true;
                $this->activity()->error(
                    action: 'generate_openai_image',
                    category: 'generator',
                    title: 'OpenAI image generation gagal.',
                    description: $error,
                    metadata: [
                        'source' => 'openai_image_queue',
                        'generation_id' => $generation->id,
                        'endpoint' => '/v1/images/edits',
                        'model' => $model,
                        'response_body' => $this->safeResponseBody($response),
                    ],
                    durationMs: $this->durationMs($startedAt),
                    httpStatus: $response->status(),
                );
                throw new RuntimeException($error);
            }

            $generation->update(['metadata' => array_merge($generation->metadata ?? [], [
                'progress' => 78,
                'progress_stage' => 'Memproses hasil OpenAI',
            ])]);

            $data = $response->json('data', []);
            if (! is_array($data) || $data === []) {
                throw new RuntimeException('OpenAI tidak mengembalikan gambar.');
            }

            $saved = 0;
            foreach ($data as $index => $item) {
                $binary = $this->resolveImageBinary($item);
                if ($binary === null || $binary === '') {
                    throw new RuntimeException('OpenAI mengembalikan item image #' . ($index + 1) . ' tanpa binary image.');
                }

                $filename = 'generation-' . $generation->id . '-' . ($index + 1) . '-' . uniqid() . '.png';
                $path = 'generations/output/' . now()->format('Y/m') . '/' . $filename;
                Storage::disk('public')->put($path, $binary);
                [$width, $height] = $this->imageDimensions(Storage::disk('public')->path($path));

                GeneratedImage::query()->create([
                    'generation_id' => $generation->id,
                    'image_path' => $path,
                    'image_url' => Storage::disk('public')->url($path),
                    'model' => $model,
                    'format' => 'png',
                    'width' => $width,
                    'height' => $height,
                    'metadata' => [
                        'openai_index' => $index,
                        'source' => 'images/edits',
                        'size' => $this->mapSize((string) $generation->aspect_ratio),
                        'quality' => $this->mapQuality((string) $generation->output_quality),
                        'stored_at' => now()->toIso8601String(),
                    ],
                    'is_primary' => $saved === 0,
                    'is_favorite' => false,
                ]);
                $saved++;
                $generation->update(['metadata' => array_merge($generation->metadata ?? [], [
                    'progress' => min(96, 82 + (int) floor(($saved / max(1, count($data))) * 14)),
                    'progress_stage' => 'Menyimpan hasil ' . $saved . '/' . count($data),
                    'saved_images' => $saved,
                ])]);
            }

            if ($saved === 0) throw new RuntimeException('Tidak ada image yang berhasil disimpan.');

            $generation->update([
                'status' => 'completed',
                'completed_at' => now(),
                'metadata' => array_merge($generation->metadata ?? [], [
                    'progress' => 100,
                    'progress_stage' => 'Selesai',
                    'saved_images' => $saved,
                    'completed_at' => now()->toIso8601String(),
                ]),
            ]);

            $this->activity()->success(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generate AI image berhasil.',
                description: sprintf('%d gambar berhasil dibuat dan disimpan. Generation #%d.', $saved, $generation->id),
                metadata: [
                    'source' => 'openai_image_queue',
                    'generation_id' => $generation->id,
                    'store_id' => $store->id,
                    'template_id' => $template->id,
                    'model' => $model,
                    'saved_images' => $saved,
                ],
                durationMs: $this->durationMs($startedAt),
                httpStatus: $response->status(),
            );

            return $generation->fresh(['generatedImages', 'store', 'template']);
        } catch (Throwable $e) {
            $generation->update([
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
                'metadata' => array_merge($generation->metadata ?? [], [
                    'progress' => 100,
                    'progress_stage' => 'Gagal',
                    'failed_at' => now()->toIso8601String(),
                ]),
            ]);

            if (! $httpErrorLogged) {
                $this->activity()->error(
                    action: 'generate_openai_image',
                    category: 'generator',
                    title: 'Generate AI image gagal.',
                    description: $e->getMessage(),
                    metadata: [
                        'source' => 'openai_image_queue',
                        'generation_id' => $generation->id,
                        'model' => $generation->model,
                        'exception' => get_class($e),
                    ],
                    durationMs: $this->durationMs($startedAt),
                );
            }
            throw $e;
        }
    }

    private function buildPrompt(Store $store, Template $template, bool $hasInstalledReference = false): string
    {
        $referenceRoles = [
            'REFERENCE IMAGE ROLES:',
            '- IMAGE 1: The primary product / packaging reference. Preserve its exact product identity, shape, proportions, colors, materials, markings and important details.',
            $hasInstalledReference
                ? '- IMAGE 2: The optional installed-product reference. Use it to understand real-world installation, positioning and usage without replacing the identity of IMAGE 1.'
                : '- No installed-product reference was supplied. Do not assume or invent a second product reference.',
            $store->logo_path
                ? ($hasInstalledReference
                    ? '- IMAGE 3: The official Store logo. Preserve it accurately as a branding reference; do not redesign, distort or replace it.'
                    : '- IMAGE 2: The official Store logo. Preserve it accurately as a branding reference; do not redesign, distort or replace it.')
                : '- No Store logo asset is configured; do not invent a logo.',
        ];

        $parts = [
            trim((string) $template->prompt),
            '',
            ...$referenceRoles,
            '',
            'STORE BRANDING CONTEXT:',
            'Store: ' . ($store->brand_name ?: $store->name),
            'Marketplace: ' . ($store->marketplace ?: 'Marketplace'),
            'Brand description: ' . ($store->description ?: 'Use the selected store visual identity consistently.'),
            $store->logo_path
                ? 'Official store logo is supplied as an image reference and must not be redesigned, distorted or replaced.'
                : 'No store logo asset is currently configured; do not invent a logo.',
            '',
            'GENERATION RULES:', 
            '- Preserve the exact identity, shape, proportions, color and important details of the supplied product.',
            '- Do not invent or replace the product.',
            '- Create a clean, premium marketplace-ready visual.',
            '- Follow the selected template composition and aspect ratio.',
            '- Use the store branding context as the brand source of truth.',
            '- Do not add random text, prices, watermarks or unrelated objects unless the template prompt explicitly asks for them.',
        ];

        return implode("\n", array_filter($parts, fn ($part) => $part !== null));
    }

    private function mapSize(string $aspectRatio): string
    {
        return match ($aspectRatio) {
            '16:9' => '1536x1024',
            '4:5', '3:4', '9:16' => '1024x1536',
            default => '1024x1024',
        };
    }

    private function mapQuality(string $quality): string
    {
        return $quality === 'high' ? 'high' : 'medium';
    }

    private function resolveImageBinary(array $item): ?string
    {
        if (! empty($item['b64_json'])) {
            $binary = base64_decode($item['b64_json'], true);

            if ($binary === false) {
                throw new RuntimeException('OpenAI mengembalikan b64_json yang tidak valid.');
            }

            return $binary;
        }

        if (! empty($item['url'])) {
            $response = Http::timeout(120)->get($item['url']);

            if (! $response->successful()) {
                throw new RuntimeException(
                    'Gagal mengambil hasil image dari URL OpenAI. HTTP ' . $response->status() . '.'
                );
            }

            return $response->body();
        }

        return null;
    }

    private function imageDimensions(string $path): array
    {
        $size = @getimagesize($path);

        return [$size[0] ?? null, $size[1] ?? null];
    }

    private function extractError(Response $response): string
    {
        $message = $response->json('error.message');

        if (is_string($message) && trim($message) !== '') {
            return trim($message) . ' (HTTP ' . $response->status() . ')';
        }

        return 'OpenAI image generation gagal. HTTP ' . $response->status() . '.';
    }

    private function safeResponseBody(Response $response): ?string
    {
        $body = trim($response->body());

        if ($body === '') {
            return null;
        }

        // Never expose the API key or authorization header in Activity Logs.
        return mb_substr($body, 0, 1000);
    }

    private function activity(): ActivityLogService
    {
        return app(ActivityLogService::class);
    }

    private function durationMs(float $startedAt): int
    {
        return (int) round((microtime(true) - $startedAt) * 1000);
    }
}
