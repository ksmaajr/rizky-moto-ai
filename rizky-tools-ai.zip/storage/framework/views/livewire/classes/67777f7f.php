<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Component;

return new
#[Layout('layouts::auth')]
class extends Component
{
    public string $email = '';

    public string $password = '';

    public bool $remember = false;


    /*
    |--------------------------------------------------------------------------
    | LOGIN
    |--------------------------------------------------------------------------
    */

    public function login(): void
    {
        try {
            $this->validate([
                'email' => [
                    'required',
                    'email',
                ],

                'password' => [
                    'required',
                    'string',
                ],
            ], [
                'email.required' => 'Email tidak boleh kosong!',
                'email.email' => 'Masukkan alamat email yang valid.',
                'password.required' => 'Password tidak boleh kosong!.',
            ]);
        } catch (ValidationException $e) {
            $errors = $e->validator->errors();

            $message = $errors->first();

            $this->dispatch(
                'toast',
                type: 'warning',
                title: 'Warning',
                message: $message
            );

            throw $e;
        }

        

        try {
            $this->ensureIsNotRateLimited();
        } catch (ValidationException $e) {
            $message = $e->validator->errors()->first();

            $this->dispatch(
                'toast',
                type: 'warning',
                title: 'Terlalu banyak percobaan',
                message: $message
            );

            throw $e;
        }

        if (! Auth::attempt([
            'email' => $this->email,
            'password' => $this->password,
        ], $this->remember)) {

            RateLimiter::hit(
                $this->throttleKey()
            );

            $this->dispatch(
                'toast',
                type: 'error',
                title: 'Login Failed',
                message: 'Email atau password yang kamu masukkan salah.'
            );

            throw ValidationException::withMessages([
                'email' => 'Email atau password yang kamu masukkan salah.',
            ]);
        }

        RateLimiter::clear(
            $this->throttleKey()
        );

        request()
            ->session()
            ->regenerate();

        $this->dispatch(
            'toast',
            type: 'success',
            title: 'Login berhasil',
            message: 'Selamat datang kembali di AI Creative Tools.'
        );

        $this->redirect(
            route('dashboard'),
            navigate: true
        );
    }


    /*
    |--------------------------------------------------------------------------
    | RATE LIMIT
    |--------------------------------------------------------------------------
    */

    protected function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts(
            $this->throttleKey(),
            5
        )) {
            return;
        }


        $seconds = RateLimiter::availableIn(
            $this->throttleKey()
        );


        throw ValidationException::withMessages([
            'email' =>
                "Terlalu banyak percobaan login. Coba lagi dalam {$seconds} detik.",
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | THROTTLE KEY
    |--------------------------------------------------------------------------
    */

    protected function throttleKey(): string
    {
        return Str::transliterate(
            Str::lower($this->email)
            . '|'
            . request()->ip()
        );
    }

    protected function view($data = [])
    {
        return app('view')->file('F:\Website\rizky-tools-ai\storage\framework\views/livewire/views/67777f7f.blade.php', $data);
    }
};

