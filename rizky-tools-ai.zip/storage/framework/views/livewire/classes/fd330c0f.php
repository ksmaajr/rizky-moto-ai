<?php

use App\Models\Store;
use App\Models\Template;
use App\Models\Generation;
use Livewire\Component;
use Livewire\WithFileUploads;

return new class extends Component
{
    use WithFileUploads;

    public ?int $selectedStoreId = null;
    public ?int $selectedTemplateId = null;
    public string $templateSearch = '';
    public string $templateCategory = 'all';
    public bool $historyOpen = true;
    public bool $useInstalledReference = true;
    public string $historyStatus = 'all';
    public string $historySearch = '';
    public ?int $historyStoreId = null;
    public ?int $historyTemplateId = null;

    public $imageOne = null;
    public $imageTwo = null;

    public string $model = '';
    public string $aspectRatio = '1:1';
    public string $quality = 'high';
    public int $imageCount = 1;
    public bool $isGenerating = false;
    public ?int $latestGenerationId = null;

    public function getStoresProperty()
    {
        return Store::query()
            ->where('is_active', true)
            ->with('templates')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();
    }

    public function getSelectedStoreProperty(): ?Store
    {
        return $this->selectedStoreId
            ? $this->stores->firstWhere('id', $this->selectedStoreId)
            : null;
    }

    public function getTemplatesProperty()
    {
        if (!$this->selectedStoreId) {
            return collect();
        }

        return Template::query()
            ->where('store_id', $this->selectedStoreId)
            ->where('is_active', true)
            ->when($this->templateSearch !== '', function ($query) {
                $keyword = '%' . trim($this->templateSearch) . '%';

                $query->where(function ($q) use ($keyword) {
                    $q->where('name', 'like', $keyword)
                        ->orWhere('description', 'like', $keyword);
                });
            })
            ->when($this->templateCategory !== 'all', function ($query) {
                $query->where(function ($q) {
                    $q->where('name', 'like', '%' . $this->templateCategory . '%')
                        ->orWhere('description', 'like', '%' . $this->templateCategory . '%');
                });
            })
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();
    }

    public function getSelectedTemplateProperty(): ?Template
    {
        return $this->selectedTemplateId
            ? $this->templates->firstWhere('id', $this->selectedTemplateId)
            : null;
    }

    public function getRecentGenerationsProperty()
    {
        return Generation::query()
            ->with(['store', 'template', 'generatedImages'])
            ->when($this->historyStatus !== 'all', fn ($q) => $q->where('status', $this->historyStatus))
            ->when($this->historyStoreId, fn ($q) => $q->where('store_id', $this->historyStoreId))
            ->when($this->historyTemplateId, fn ($q) => $q->where('template_id', $this->historyTemplateId))
            ->when(trim($this->historySearch) !== '', function ($q) {
                $keyword = '%' . trim($this->historySearch) . '%';
                $q->where(function ($inner) use ($keyword) {
                    $inner->whereHas('store', fn ($store) => $store->where('name', 'like', $keyword))
                        ->orWhereHas('template', fn ($template) => $template->where('name', 'like', $keyword))
                        ->orWhere('id', 'like', $keyword);
                });
            })
            ->latest()
            ->limit(12)
            ->get();
    }

    public function getHasActiveGenerationsProperty(): bool
    {
        return Generation::query()
            ->whereIn('status', ['queued', 'processing'])
            ->exists();
    }

    public function getHistoryTemplatesProperty()
    {
        return Template::query()->where('is_active', true)->orderBy('name')->get(['id', 'name']);
    }

    public function getLatestGenerationProperty(): ?Generation
    {
        if ($this->latestGenerationId) {
            return Generation::query()
                ->with(['store', 'template', 'generatedImages'])
                ->find($this->latestGenerationId);
        }

        return Generation::query()
            ->with(['store', 'template', 'generatedImages'])
            ->whereIn('status', ['completed', 'success', 'succeeded'])
            ->latest()
            ->first();
    }

    public function getAvailableModelsProperty(): array
    {
        try {
            return app(\App\Services\OpenAiService::class)->availableImageModels();
        } catch (\Throwable $e) {
            report($e);
            return [];
        }
    }

    public function mount(): void
    {
        $settings = \App\Models\OpenAiSetting::query()->first();

        $this->model = $settings?->model ?: '';
        $this->aspectRatio = $settings?->default_aspect_ratio ?: '1:1';
        $this->quality = $settings?->default_quality ?: 'high';

        $latest = Generation::query()
            ->whereIn('status', ['completed', 'success', 'succeeded'])
            ->latest()
            ->value('id');

        $this->latestGenerationId = $latest ? (int) $latest : null;

        if ($this->model === '' && ! empty($this->availableModels)) {
            $this->model = $this->availableModels[0]['id'];
        }
    }

    public function selectStore(int $storeId): void
    {
        $this->selectedStoreId = $storeId;
        $this->selectedTemplateId = null;
        $this->templateSearch = '';
    }

    public function toggleTemplate(int $templateId): void
    {
        $template = Template::query()
            ->where('id', $templateId)
            ->where('store_id', $this->selectedStoreId)
            ->where('is_active', true)
            ->firstOrFail();

        if ($this->selectedTemplateId === $templateId) {
            $this->selectedTemplateId = null;
            return;
        }

        $this->selectedTemplateId = $templateId;

        // Template adalah source of truth untuk default generator settings.
        $this->aspectRatio = $template->aspect_ratio ?: '1:1';
        $this->quality = $template->output_quality ?: 'high';
    }

    public function generate(): void
    {
        $startedAt = microtime(true);
        $activity = app(\App\Services\ActivityLogService::class);

        if (! $this->useInstalledReference) {
            $this->imageTwo = null;
        }

        try {
            $this->validate([
                'selectedStoreId' => ['required', 'integer', 'exists:stores,id'],
                'selectedTemplateId' => ['required', 'integer', 'exists:templates,id'],
                'imageOne' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
                'imageTwo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
                'model' => ['required', 'string', 'max:150'],
                'aspectRatio' => ['required', 'in:1:1,4:5,3:4,16:9,9:16'],
                'quality' => ['required', 'in:standard,high'],
                'imageCount' => ['required', 'integer', 'min:1', 'max:4'],
            ], [
                'selectedStoreId.required' => 'Pilih Store terlebih dahulu.',
                'selectedTemplateId.required' => 'Pilih Template terlebih dahulu.',
                'imageOne.required' => 'Gambar utama wajib diupload.',
                'imageTwo.image' => 'Foto referensi pemasangan harus berupa gambar yang valid.',
                'imageTwo.mimes' => 'Foto referensi harus JPG, PNG, atau WEBP.',
                'imageTwo.max' => 'Foto referensi maksimal 10MB.',
                'model.required' => 'Model OpenAI belum tersedia. Pastikan API Key sudah tersimpan.',
            ]);

            $template = Template::query()
                ->whereKey($this->selectedTemplateId)
                ->where('store_id', $this->selectedStoreId)
                ->where('is_active', true)
                ->firstOrFail();

            $this->aspectRatio = $template->aspect_ratio ?: $this->aspectRatio;
            $this->quality = $template->output_quality ?: $this->quality;

            $generation = app(\App\Services\OpenAiImageService::class)->queueGeneration(
                user: auth()->user(),
                store: $this->selectedStore,
                template: $template,
                imageOne: $this->imageOne,
                imageTwo: $this->useInstalledReference ? $this->imageTwo : null,
                model: $this->model,
                aspectRatio: $this->aspectRatio,
                quality: $this->quality,
                imageCount: $this->imageCount,
            );

            \App\Jobs\GenerateOpenAiImageJob::dispatch($generation->id);

            $this->latestGenerationId = $generation->id;
            $this->isGenerating = false;

            $this->dispatch(
                'toast',
                type: 'success',
                title: 'Generation masuk antrean',
                message: 'Kamu bisa langsung membuat generate lain. Proses berjalan di Recent History.'
            );

            $this->dispatch('activity-log-refresh');
        } catch (\Illuminate\Validation\ValidationException $e) {
            $message = $e->validator->errors()->first();

            $activity->error(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generate AI image gagal pada validasi.',
                description: $message,
                metadata: [
                    'source' => 'generator_component',
                    'reason' => 'validation',
                    'store_id' => $this->selectedStoreId,
                    'template_id' => $this->selectedTemplateId,
                ],
                durationMs: (int) round((microtime(true) - $startedAt) * 1000),
            );

            $this->dispatch('activity-log-refresh');
            throw $e;
        } catch (\Throwable $e) {
            report($e);
            $activity->error(
                action: 'generate_openai_image',
                category: 'generator',
                title: 'Generation gagal dimasukkan ke antrean.',
                description: $e->getMessage(),
                metadata: [
                    'source' => 'generator_component',
                    'reason' => 'queue_dispatch',
                    'store_id' => $this->selectedStoreId,
                    'template_id' => $this->selectedTemplateId,
                ],
                durationMs: (int) round((microtime(true) - $startedAt) * 1000),
            );

            $this->dispatch('activity-log-refresh');
            $this->dispatch('toast', type: 'error', title: 'Tidak bisa memulai generate', message: $e->getMessage());
        }
    }

    public function setReferenceMode(bool $enabled): void
    {
        $this->useInstalledReference = $enabled;

        if (! $enabled) {
            $this->imageTwo = null;
        }
    }

    public function selectModel(string $model): void
    {
        if (! collect($this->availableModels)->pluck('id')->contains($model)) {
            return;
        }

        $this->model = $model;
    }

    public function clearImageOne(): void
    {
        $this->imageOne = null;
    }

    public function clearImageTwo(): void
    {
        $this->imageTwo = null;
    }

    protected function view($data = [])
    {
        return app('view')->file('F:\Website\rizky-tools-ai\storage\framework\views/livewire/views/fd330c0f.blade.php', $data);
    }
};
