<?php

use Livewire\Attributes\Layout;
use Livewire\Component;
use App\Models\Store;

return new
#[Layout('layouts::app')]
class extends Component
{
    public function getUserProperty(): ?object
    {
        return auth()->user();
    }

    public string $activeSection = 'dashboard';

    // Settings workspace state
    public string $activeTab = 'general';
    public bool $showApiKey = false;
    public string $apiKey = '';
    public string $imageModel = 'OpenAI Image Generation';
    public string $defaultAspectRatio = '1:1';
    public string $defaultQuality = 'standard';
    public bool $hasOpenAiKey = false;

    public string $storeSearch = '';
    public string $storeStatus = 'all';

    // Global activity log workspace.
    public array $activityLogs = [];
    public string $activitySearch = '';
    public string $activityCategory = 'all';
    public string $activityStatus = 'all';
    public string $activityTimeframe = 'all';


    public function mount(): void
    {
        $settings = \App\Models\OpenAiSetting::query()->first();

        if ($settings) {
            $this->imageModel = $settings->model ?: 'OpenAI Image Generation';
            $this->defaultAspectRatio = $settings->default_aspect_ratio ?: '1:1';
            $this->defaultQuality = $settings->default_quality ?: 'standard';
            $this->hasOpenAiKey = filled($settings->api_key);
        }

        $this->loadActivityLogs();
    }

    private function loadActivityLogs(): void
    {
        $query = \App\Models\ActivityLog::query()
            ->latest('created_at');

        $search = trim($this->activitySearch);

        if ($search !== '') {
            $keyword = '%' . $search . '%';

            $query->where(function ($q) use ($keyword) {
                $q->where('title', 'like', $keyword)
                    ->orWhere('description', 'like', $keyword)
                    ->orWhere('action', 'like', $keyword)
                    ->orWhere('category', 'like', $keyword)
                    ->orWhere('metadata', 'like', $keyword);
            });
        }

        if ($this->activityCategory !== 'all') {
            $query->where('category', $this->activityCategory);
        }

        if ($this->activityStatus !== 'all') {
            $query->where('status', $this->activityStatus);
        }

        if ($this->activityTimeframe !== 'all') {
            $from = match ($this->activityTimeframe) {
                'today' => now()->startOfDay(),
                '7d' => now()->subDays(7)->startOfDay(),
                '30d' => now()->subDays(30)->startOfDay(),
                default => null,
            };

            if ($from) {
                $query->where('created_at', '>=', $from);
            }
        }

        $this->activityLogs = $query
            ->limit(100)
            ->get()
            ->map(fn ($log) => [
                'id' => $log->id,
                'category' => $log->category,
                'action' => $log->action,
                'status' => $log->status,
                'title' => $log->title,
                'description' => $log->description,
                'metadata' => $log->metadata ?? [],
                'duration_ms' => $log->duration_ms,
                'http_status' => $log->http_status,
                'entity_type' => $log->entity_type,
                'entity_id' => $log->entity_id,
                'created_at' => $log->created_at?->format('d M Y, H:i:s'),
                'created_at_human' => $log->created_at?->diffForHumans(),
            ])
            ->toArray();
    }

    public function refreshActivityLogs(): void
    {
        $this->loadActivityLogs();
    }

    public function getActivityLogCountProperty(): int
    {
        return \App\Models\ActivityLog::query()->count();
    }

    public function getFilteredActivityLogCountProperty(): int
    {
        return count($this->activityLogs);
    }

    public function getOpenAiStatusProperty(): array
    {
        $settings = \App\Models\OpenAiSetting::query()->first();

        $latest = \App\Models\ActivityLog::query()
            ->where('category', 'api')
            ->where('action', 'test_openai_connection')
            ->latest('created_at')
            ->first();

        if (! $settings || ! filled($settings->api_key)) {
            return [
                'state' => 'not_configured',
                'label' => 'Not configured',
                'subtitle' => 'API key belum disimpan',
                'badge' => 'STEP 0',
            ];
        }

        if ($latest?->status === 'success') {
            return [
                'state' => 'connected',
                'label' => 'Connected',
                'subtitle' => 'OpenAI API authenticated',
                'badge' => 'LIVE',
            ];
        }

        if ($latest?->status === 'error') {
            return [
                'state' => 'error',
                'label' => 'Connection error',
                'subtitle' => 'Periksa Connection Logs',
                'badge' => 'CHECK',
            ];
        }

        return [
            'state' => 'configured',
            'label' => 'Configured',
            'subtitle' => 'Run connection test',
            'badge' => 'STEP 1',
        ];
    }

    public function getFavoriteCountProperty(): int
    {
        return \App\Models\GeneratedImage::query()
            ->where('is_favorite', true)
            ->count();
    }

    public function getStoresProperty()
    {
        return Store::query()
            ->withCount(['templates', 'generations'])
            ->when($this->storeSearch !== '', function ($query) {
                $keyword = '%' . trim($this->storeSearch) . '%';
                $query->where(function ($q) use ($keyword) {
                    $q->where('name', 'like', $keyword)
                        ->orWhere('brand_name', 'like', $keyword)
                        ->orWhere('marketplace', 'like', $keyword);
                });
            })
            ->when($this->storeStatus === 'active', fn ($query) => $query->where('is_active', true))
            ->when($this->storeStatus === 'inactive', fn ($query) => $query->where('is_active', false))
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();
    }

    public function getTotalStoresProperty(): int
    {
        return Store::count();
    }

    public function getActiveStoresProperty(): int
    {
        return Store::where('is_active', true)->count();
    }

    public function getTotalTemplatesProperty(): int
    {
        return (int) Store::withCount('templates')->get()->sum('templates_count');
    }

    public function getTotalGenerationsProperty(): int
    {
        return (int) Store::withCount('generations')->get()->sum('generations_count');
    }

    public function getUserInitialsProperty(): string
    {
        $name = trim((string) ($this->user?->name ?? 'User'));
        $parts = preg_split('/\s+/', $name) ?: [];

        return collect($parts)
            ->filter()
            ->take(2)
            ->map(fn ($part) => strtoupper(substr($part, 0, 1)))
            ->implode('') ?: 'U';
    }

    public function openStore(): void
    {
        $this->activeSection = 'stores';

        $this->dispatch('workspace-section-changed', section: 'stores');
    }

    public function openDashboard(): void
    {
        $this->activeSection = 'dashboard';

        $this->dispatch('workspace-section-changed', section: 'dashboard');
    }

    public function openTemplates(): void
    {
        $this->activeSection = 'templates';
    }

    public function openGenerator(): void
    {
        $this->activeSection = 'generator';
    }

    public function openSettings(): void
    {
        $this->activeSection = 'settings-general';
        $this->activeTab = 'general';
    }

    public function openGeneralSettings(): void
    {
        $this->activeSection = 'settings-general';
        $this->activeTab = 'general';
    }

    public function openOpenAiSettings(): void
    {
        $this->activeSection = 'settings-openai';
        $this->activeTab = 'openai';
    }

    public function selectTab(string $tab): void
    {
        if (! in_array($tab, ['general', 'openai'], true)) {
            return;
        }

        $this->activeTab = $tab;
        $this->activeSection = $tab === 'openai'
            ? 'settings-openai'
            : 'settings-general';
    }

    public function testConnection(): void
    {
        try {
            $result = app(\App\Services\OpenAiService::class)->testConnection(
                apiKey: trim($this->apiKey) !== '' ? trim($this->apiKey) : null,
                model: $this->imageModel,
            );

            $this->hasOpenAiKey = $result['has_key'];

            $this->dispatch(
                'openai-test-result',
                type: $result['status'],
                message: $result['message'],
                detail: $result['detail'],
            );

            $this->dispatch(
                'toast',
                type: $result['status'] === 'success' ? 'success' : ($result['status'] === 'warning' ? 'warning' : 'error'),
                title: $result['title'],
                message: $result['message'],
            );
        } catch (\Throwable $e) {
            report($e);

            $this->dispatch(
                'openai-test-result',
                type: 'error',
                message: 'Test koneksi gagal.',
                detail: 'Terjadi error internal saat menghubungi OpenAI.',
            );

            $this->dispatch(
                'toast',
                type: 'error',
                title: 'Test koneksi gagal',
                message: 'Terjadi error internal. Periksa log Laravel.',
            );
        }
        $this->loadActivityLogs();
    }

    public function clearActivityLogs(): void
    {
        try {
            \App\Models\ActivityLog::query()->delete();
            $this->loadActivityLogs();

            $this->dispatch(
                'toast',
                type: 'success',
                title: 'Activity logs dibersihkan',
                message: 'Seluruh riwayat aktivitas sudah dihapus.'
            );
        } catch (\Throwable $e) {
            report($e);

            $this->dispatch(
                'toast',
                type: 'error',
                title: 'Gagal membersihkan logs',
                message: 'Activity logs tidak dapat dihapus.'
            );
        }
    }

    public function saveOpenAi(): void
    {
        try {
            $this->validate([
                'apiKey' => ['nullable', 'string', 'max:500'],
            ]);

            $existing = \App\Models\OpenAiSetting::query()->first();
            $newApiKey = trim((string) $this->apiKey);

            if ($newApiKey === '' && ! filled($existing?->api_key)) {
                $this->dispatch(
                    'toast',
                    type: 'warning',
                    title: 'API Key belum diisi',
                    message: 'Masukkan API Key OpenAI terlebih dahulu.'
                );

                return;
            }

            $savedSettings = app(\App\Services\OpenAiService::class)->saveApiKey(
                $newApiKey !== '' ? $newApiKey : null,
            );

            $this->hasOpenAiKey = filled($savedSettings->api_key);

            if (! $this->hasOpenAiKey) {
                $this->dispatch(
                    'toast',
                    type: 'error',
                    title: 'API Key gagal disimpan',
                    message: 'Credential tidak berhasil tersimpan di database.'
                );

                return;
            }

            app(\App\Services\ActivityLogService::class)->success(
                category: 'api',
                action: 'update_openai_configuration',
                title: 'OpenAI API configuration diperbarui.',
                description: 'Credential OpenAI berhasil disimpan melalui backend.',
            );

            $this->apiKey = '';
            $this->showApiKey = false;
            $this->loadActivityLogs();

            $this->dispatch(
                'toast',
                type: 'success',
                title: 'Konfigurasi tersimpan',
                message: 'OpenAI API siap digunakan oleh Product Generator.'
            );
        } catch (\Illuminate\Validation\ValidationException $e) {
            $this->dispatch(
                'toast',
                type: 'warning',
                title: 'Periksa konfigurasi',
                message: $e->validator->errors()->first()
            );

            throw $e;
        } catch (\Throwable $e) {
            report($e);

            $this->dispatch(
                'toast',
                type: 'error',
                title: 'Gagal menyimpan',
                message: 'Konfigurasi OpenAI tidak dapat disimpan.'
            );
        }
    }

    public function saveGeneral(): void
    {
        $this->dispatch(
            'toast',
            type: 'success',
            title: 'Preferences siap',
            message: 'Pengaturan workspace sudah siap disimpan.'
        );
    }

    protected function view($data = [])
    {
        return app('view')->file('F:\Website\rizky-tools-ai\storage\framework\views/livewire/views/f04a7103.blade.php', $data);
    }
};

