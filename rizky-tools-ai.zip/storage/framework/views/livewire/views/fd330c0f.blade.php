<?php
use App\Models\Store;
use App\Models\Template;
use App\Models\Generation;
use Livewire\Component;
use Livewire\WithFileUploads;
?>

<div
    class="rms-generator-page"
    x-data="rmsImageGenerator()"
    @keydown.escape.window="
        previewOpen
            ? closePreview()
            : closeAllMenus()
    "
>
    <div class="rms-generator-head">
        <div>
            <span class="rms-generator-eyebrow"><i></i> AI CREATIVE TOOL</span>
            <h1>AI Image Generator<span>.</span></h1>
            <p>Buat visual produk menggunakan Store dan Template yang sudah disiapkan.</p>
        </div>

        <div class="rms-generator-head-note">
            <span class="rms-generator-note-icon">✦</span>
            <div>
                <strong>Template based generation</strong>
                <small>Pilih Store terlebih dahulu untuk melihat template yang tersedia.</small>
            </div>
        </div>
    </div>

    <div class="rms-generator-layout" :class="{ 'history-collapsed': !historyOpen }">

        <section class="rms-generator-workspace">

            <div class="rms-generator-stepbar rms-generator-stepbar-v2">
                <div class="rms-generator-step"
                    :class="{ 'is-active': activeStep === 1, 'is-complete': activeStep > 1 }">
                    <b><span x-show="activeStep <= 1">1</span><span x-show="activeStep > 1">✓</span></b>
                    <span><strong>Pilih Store & Template</strong><small>Pilih Store lalu preset visual.</small></span>
                </div>
                <i :class="{ 'is-filled': activeStep > 1 }"></i>
                <div class="rms-generator-step"
                    :class="{ 'is-active': activeStep === 2, 'is-complete': activeStep > 2 }">
                    <b><span x-show="activeStep <= 2">2</span><span x-show="activeStep > 2">✓</span></b>
                    <span><strong>Upload Gambar</strong><small>Masukkan foto produk.</small></span>
                </div>
                <i :class="{ 'is-filled': activeStep > 2 }"></i>
                <div class="rms-generator-step"
                    :class="{ 'is-active': activeStep === 3 }">
                    <b>3</b>
                    <span><strong>Pengaturan & Generate</strong><small>Atur output lalu mulai.</small></span>
                </div>
            </div>

            <div class="rms-generator-columns">

                <section id="generator-step-1" class="rms-generator-card rms-generator-selection">
                    <div class="rms-generator-card-head">
                        <div>
                            <span>STEP 01</span>
                            <h2>Pilih Store & Template</h2>
                            <p>Template akan menyesuaikan dengan Store yang dipilih.</p>
                        </div>
                    </div>

                    <label class="rms-generator-field-label">Store <em>*</em></label>

                    <div class="rms-generator-store-select" x-data="{ open:false }" @click.outside="open=false">
                        <button type="button" class="rms-generator-store-trigger" :class="{ 'is-open': open }" @click="open=!open">
                            <?php if ($this->selectedStore) : ?>
                                <span class="rms-generator-store-logo">
                                    <?php if ($this->selectedStore->logo_path) : ?>
                                        <img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($this->selectedStore->logo_path) }}" alt="">
                                    <?php else: ?>
                                        <b>{{ strtoupper(substr($this->selectedStore->name, 0, 1)) }}</b>
                                    <?php endif; ?>
                                </span>
                                <span class="rms-generator-store-copy">
                                    <strong>{{ $this->selectedStore->name }}</strong>
                                    <small>{{ $this->selectedStore->marketplace ?: 'Marketplace' }}</small>
                                </span>
                            <?php else: ?>
                                <span class="rms-generator-store-placeholder">Pilih Store</span>
                            <?php endif; ?>
                            <span class="rms-generator-chevron" :class="{ 'is-open': open }">
                                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg>
                            </span>
                        </button>

                        <div class="rms-generator-store-menu" x-show="open" x-transition.opacity.scale.origin.top style="display:none">
                            <div class="rms-generator-menu-head">
                                <div>
                                    <span>SELECT STORE</span>
                                    <small>Template owner</small>
                                </div>
                                <b>{{ $this->stores->count() }}</b>
                            </div>

                            <?php $__blade_forelse_1 = $this->stores; if ($__blade_forelse_1->isNotEmpty()): foreach ($__blade_forelse_1 as $store): ?>
                                <button type="button"
                                    class="{{ (int)$selectedStoreId === (int)$store->id ? 'selected' : '' }}"
                                    wire:click="selectStore({{ $store->id }})"
                                    @click="open=false">
                                    <span class="rms-generator-option-logo">
                                        <?php if ($store->logo_path) : ?>
                                            <img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($store->logo_path) }}" alt="">
                                        <?php else: ?>
                                            <b>{{ strtoupper(substr($store->name, 0, 1)) }}</b>
                                        <?php endif; ?>
                                    </span>
                                    <span>
                                        <strong>{{ $store->name }}</strong>
                                        <small>{{ $store->marketplace ?: 'Marketplace' }} · {{ $store->templates->count() }} template</small>
                                    </span>
                                    <i>{{ (int)$selectedStoreId === (int)$store->id ? '✓' : '' }}</i>
                                </button>
                            <?php endforeach; else: ?>
                                <div class="rms-generator-empty-mini">Belum ada Store aktif.</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rms-generator-template-heading">
                        <label class="rms-generator-field-label">Template <em>*</em></label>
                        <?php if ($this->selectedStore) : ?>
                            <span>{{ $this->templates->count() }} tersedia</span>
                        <?php endif; ?>
                    </div>

                    <div class="rms-generator-search">
                        <span>⌕</span>
                        <input type="text" wire:model.live.debounce.250ms="templateSearch"
                            placeholder="{{ $this->selectedStore ? 'Cari template...' : 'Pilih Store terlebih dahulu' }}"
                            @disabled(!$this->selectedStore)>
                    </div>

                    <div class="rms-generator-chips rms-filter-drag">
                        <?php foreach (['all' => 'All', 'promo' => 'Promo', 'product' => 'Product', 'lifestyle' => 'Lifestyle', 'detail' => 'Detail'] as $key => $label): ?>
                            <button type="button"
                                class="rms-filter-chip {{ $templateCategory === $key ? 'active' : '' }}"
                                wire:click="$set('templateCategory','{{ $key }}')"
                                @disabled(!$this->selectedStore)>
                                {{ $label }}
                            </button>
                        <?php endforeach; ?>
                    </div>

                    <div class="rms-generator-template-grid">
                        <?php $__blade_forelse_2 = $this->templates; if ($__blade_forelse_2->isNotEmpty()): foreach ($__blade_forelse_2 as $template): ?>
                            <button type="button"
                                class="rms-generator-template-card {{ (int)$selectedTemplateId === (int)$template->id ? 'selected' : '' }}"
                                wire:click="toggleTemplate({{ $template->id }})" @click="$nextTick(() => activeStep = (selectedTemplateId === {{ $template->id }}) ? 2 : 1)">
                                <div class="rms-generator-template-image">
                                    <?php if ($template->example_image_path) : ?>
                                        <img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($template->example_image_path) }}" alt="">
                                    <?php else: ?>
                                        <div class="rms-generator-template-placeholder">AI</div>
                                    <?php endif; ?>
                                    <?php if ((int)$selectedTemplateId === (int)$template->id) : ?>
                                        <i>✓</i>
                                    <?php endif; ?>
                                </div>
                                <div class="rms-generator-template-copy">
                                    <strong>{{ $template->name }}</strong>
                                    <small>{{ $template->aspect_ratio ?: '1:1' }}</small>
                                </div>
                            </button>
                        <?php endforeach; else: ?>
                            <div class="rms-generator-no-template">
                                <span>✦</span>
                                <strong>{{ $this->selectedStore ? 'Belum ada template aktif' : 'Pilih Store terlebih dahulu' }}</strong>
                                <small>{{ $this->selectedStore ? 'Tambahkan template dari Template Library.' : 'Template akan muncul otomatis setelah Store dipilih.' }}</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <section id="generator-step-2" class="rms-generator-card rms-generator-upload">
                    <div class="rms-generator-card-head">
                        <div>
                            <span>STEP 02</span>
                            <h2>Upload Gambar Produk</h2>
                            <p>Foto produk wajib. Foto terpasang bersifat opsional sebagai referensi penggunaan.</p>
                        </div>
                        <div class="rms-upload-requirement" :class="{ 'optional-mode': !useInstalledReference }">
                            <i></i> <span x-text="useInstalledReference ? '3 reference images' : '2 reference images'"></span>
                        </div>
                    </div>

                    <div class="rms-generator-upload-grid rms-generator-upload-grid-v2">
                        <div class="rms-generator-upload-box rms-upload-primary" :class="{ 'has-image': imageOne }">
                            <div class="rms-upload-label-row">
                                <span class="rms-upload-number">01</span>
                                <div><strong>Foto Produk Utama <em>*</em></strong><small>Packaging / part motor sebagai sumber identitas produk.</small></div>
                                <span class="rms-upload-badge required">REQUIRED</span>
                            </div>
                            <?php if ($imageOne) : ?>
                                <div class="rms-upload-preview-wrap">
                                    <img src="{{ $imageOne->temporaryUrl() }}" alt="">
                                    <div class="rms-upload-preview-shade"></div>
                                    <button type="button" class="rms-generator-remove" wire:click="clearImageOne">×</button>
                                    <span class="rms-upload-complete">✓ Uploaded</span>
                                </div>
                            <?php else: ?>
                                <div class="rms-generator-upload-placeholder">
                                    <div class="rms-generator-upload-icon">
                                        <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 20h14"/></svg>
                                    </div>
                                    <strong>Upload foto produk</strong>
                                    <small>Gunakan foto yang paling jelas dan tajam.</small>
                                    <label class="rms-generator-upload-button">
                                        <span>↑</span> Pilih Gambar
                                        <input type="file" wire:model="imageOne" accept="image/png,image/jpeg,image/webp">
                                    </label>
                                    <em>JPG, PNG, WEBP · Maks. 10MB</em>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="rms-generator-upload-box rms-upload-reference" :class="{ 'has-image': imageTwo, 'is-disabled': !useInstalledReference }">
                            <div class="rms-upload-label-row">
                                <span class="rms-upload-number">02</span>
                                <div><strong>Foto Produk Terpasang</strong><small>Referensi bentuk, posisi, dan penggunaan part pada motor.</small></div>
                                <span class="rms-upload-badge optional">OPTIONAL</span>
                            </div>
                            <?php if ($imageTwo) : ?>
                                <div class="rms-upload-preview-wrap">
                                    <img src="{{ $imageTwo->temporaryUrl() }}" alt="">
                                    <div class="rms-upload-preview-shade"></div>
                                    <button type="button" class="rms-generator-remove" wire:click="clearImageTwo">×</button>
                                    <span class="rms-upload-complete">✓ Reference ready</span>
                                </div>
                            <?php elseif ($useInstalledReference) : ?>
                                <div class="rms-generator-upload-placeholder">
                                    <div class="rms-generator-upload-icon reference">
                                        <svg viewBox="0 0 24 24"><path d="M4 17.5V6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5Z"/><circle cx="9" cy="9" r="1.5"/><path d="m5.5 17 4.2-4.2 3 3 2.3-2.3 3.5 3.5"/></svg>
                                    </div>
                                    <strong>Tambahkan foto terpasang</strong>
                                    <small>Direkomendasikan jika tersedia untuk referensi penggunaan.</small>
                                    <label class="rms-generator-upload-button secondary">
                                        <span>↑</span> Pilih Foto
                                        <input type="file" wire:model="imageTwo" accept="image/png,image/jpeg,image/webp">
                                    </label>
                                    <em>JPG, PNG, WEBP · Maks. 10MB</em>
                                </div>
                            <?php else: ?>
                                <div class="rms-upload-disabled-state">
                                    <span>✦</span>
                                    <strong>Mode tanpa foto terpasang</strong>
                                    <small>AI akan membuat konteks visual berdasarkan produk dan template.</small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rms-reference-mode">
                        <div>
                            <span class="rms-reference-icon">✦</span>
                            <div>
                                <strong>Gunakan foto contoh produk?</strong>
                                <small>Pilih sesuai aset yang dimiliki client. Logo Store akan ditambahkan otomatis.</small>
                            </div>
                        </div>
                        <div class="rms-reference-toggle">
                            <button type="button" class="{{ $useInstalledReference ? 'active' : '' }}" wire:click="setReferenceMode(true)">Gunakan Foto Terpasang</button>
                            <button type="button" class="{{ ! $useInstalledReference ? 'active' : '' }}" wire:click="setReferenceMode(false)">Tanpa Foto Terpasang</button>
                        </div>
                    </div>

                    <div class="rms-reference-flow">
                        <span class="rms-flow-title">REFERENCE YANG AKAN DIGUNAKAN AI</span>
                        <div class="rms-flow-items">
                            <div class="rms-flow-item ready"><b>01</b><span>Product</span><small>Uploaded</small></div>
                            <i>+</i>
                            <div class="rms-flow-item {{ ! $useInstalledReference ? 'muted' : ($imageTwo ? 'ready' : '') }}"><b>02</b><span>Installed</span><small>{{ ! $useInstalledReference ? 'Skipped' : ($imageTwo ? 'Uploaded' : 'Optional') }}</small></div>
                            <i>+</i>
                            <div class="rms-flow-item ready"><b>03</b><span>Store Logo</span><small>Automatic</small></div>
                        </div>
                    </div>

                    <div class="rms-generator-result-preview">
                        <div class="rms-generator-subhead">
                            <div>
                                <strong>Preview Hasil Generate</strong>
                                <span>Hasil visual terbaru akan muncul di sini setelah proses generate selesai.</span>
                            </div>
                            <span class="rms-preview-status">
                                <i></i>
                                Latest result
                            </span>
                        </div>

                        @php
                            $latestGeneration = $this->latestGeneration;

                            $latestImages = $latestGeneration?->generatedImages
                                ?->where('is_primary', true)
                                ->take(4)
                                ?? collect();

                            if ($latestImages->isEmpty() && $latestGeneration) {
                                $latestImages = $latestGeneration->generatedImages->take(4);
                            }
                        @endphp

                        <div class="rms-generator-result-grid">
                            <?php $__blade_forelse_3 = $latestImages; if ($__blade_forelse_3->isNotEmpty()): foreach ($__blade_forelse_3 as $image): ?>
                                @php
                                    $latestPreview = [
                                        'id' => (int) $image->id,
                                        'url' => \Illuminate\Support\Facades\Storage::disk('public')->url($image->image_path),
                                        'format' => strtoupper($image->format ?: 'png'),
                                        'width' => (int) $image->width,
                                        'height' => (int) $image->height,
                                        'template' => $latestGeneration?->template?->name ?? 'Generated Image',
                                        'store' => $latestGeneration?->store?->name ?? 'Store',
                                    ];
                                @endphp
                                <div class="rms-generator-result-card" x-data="{ downloadOpen:false }">
                                    <img
                                        src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($image->image_path) }}"
                                        alt="Generated image preview"
                                        loading="lazy"
                                    >
                                    <div class="rms-result-overlay">
                                        <span>GENERATED · {{ strtoupper($image->format ?: 'png') }}</span>
                                        <div class="rms-result-actions">
                                            <button type="button" class="rms-result-preview-button"
                                                @click="openPreview({{ \Illuminate\Support\Js::from($latestPreview) }})" title="Preview image">⌕</button>
                                            <a
                                                class="rms-result-download-primary"
                                                href="{{ route('generated-images.download', ['generatedImage' => $image->id, 'max_mb' => 2, 'quality' => 85, 'format' => 'jpg']) }}"
                                                title="Download maksimal 2 MB"
                                            >↓ 2MB</a>
                                            <button type="button" @click="downloadOpen=!downloadOpen" class="rms-result-download-more" title="Custom download">•••</button>
                                            <div class="rms-download-menu" x-show="downloadOpen" x-transition.opacity.scale.origin.bottom.right @click.outside="downloadOpen=false" style="display:none">
                                                <div class="rms-download-menu-title">CUSTOM DOWNLOAD</div>
                                                <a href="{{ route('generated-images.download', ['generatedImage' => $image->id, 'max_mb' => 2, 'quality' => 90, 'format' => 'jpg']) }}">JPG · High · ≤ 2 MB</a>
                                                <a href="{{ route('generated-images.download', ['generatedImage' => $image->id, 'max_mb' => 2, 'quality' => 75, 'format' => 'jpg']) }}">JPG · Balanced · ≤ 2 MB</a>
                                                <a href="{{ route('generated-images.download', ['generatedImage' => $image->id, 'max_mb' => 1, 'quality' => 78, 'format' => 'webp']) }}">WEBP · Compact · ≤ 1 MB</a>
                                                <a href="{{ route('generated-images.download', ['generatedImage' => $image->id, 'max_mb' => 3, 'quality' => 90, 'format' => 'jpg']) }}">JPG · High · ≤ 3 MB</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; else: ?>
                                <div class="rms-generator-result-empty">
                                    <span class="rms-result-empty-icon">
                                        <svg viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5z"/>
                                            <circle cx="8.5" cy="9" r="1.2"/>
                                            <path d="m5.5 17 4.5-4.5 3 3 2-2 3.5 3.5"/>
                                        </svg>
                                    </span>
                                    <strong>Belum ada hasil generate</strong>
                                    <small>Preview akan tampil otomatis setelah generate berhasil dan statusnya selesai.</small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rms-generator-settings">
                        <div class="rms-generator-subhead">
                            <div>
                                <strong>Pengaturan Tambahan</strong>
                                <span>Sesuaikan output sebelum generate</span>
                            </div>
                            <button type="button" class="rms-settings-collapse" @click="settingsOpen = !settingsOpen" :class="{ 'is-open': settingsOpen }">
                                <svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>
                            </button>
                        </div>

                        <div class="rms-generator-settings-grid" x-show="settingsOpen" x-transition.opacity>
                            <div class="rms-custom-select rms-custom-select-enhanced full" x-data="{ open:false }" @click.outside="open=false">
                                <span class="rms-custom-select-label">Model OpenAI</span>
                                <button type="button" class="rms-custom-select-trigger" :class="{ 'is-open': open }" @click="open=!open">
                                    <span>
                                        <b>{{ $model ?: 'Model belum tersedia' }}</b>
                                        <small>{{ count($this->availableModels) }} model image tersedia dari OpenAI</small>
                                    </span>
                                    <i><svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg></i>
                                </button>
                                <div class="rms-custom-select-menu" x-show="open" x-transition.opacity.scale.origin.top style="display:none">
                                    <?php $__blade_forelse_4 = $this->availableModels; if ($__blade_forelse_4->isNotEmpty()): foreach ($__blade_forelse_4 as $openAiModel): ?>
                                        <button type="button" class="{{ $model === $openAiModel['id'] ? 'selected' : '' }}" wire:click="selectModel('{{ addslashes($openAiModel['id']) }}')" @click="open=false">
                                            <span class="rms-option-model">AI</span>
                                            <span>
                                                <strong>{{ $openAiModel['id'] }}</strong>
                                                <small>{{ $openAiModel['owned_by'] ?? 'OpenAI' }}</small>
                                            </span>
                                            <i>{{ $model === $openAiModel['id'] ? '✓' : '' }}</i>
                                        </button>
                                    <?php endforeach; else: ?>
                                        <div class="rms-generator-empty-mini">Model image tidak ditemukan dari OpenAI. Cek API Key dan koneksi.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="rms-custom-select rms-custom-select-enhanced" x-data="{ open:false }" @click.outside="open=false">
                                <span class="rms-custom-select-label">Aspect Ratio</span>
                                <button type="button" class="rms-custom-select-trigger" :class="{ 'is-open': open }" @click="open=!open">
                                    <span>
                                        <b x-text="aspectRatioLabel('{{ $aspectRatio }}')"></b>
                                        <small>Canvas output</small>
                                    </span>
                                    <i><svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg></i>
                                </button>
                                <div class="rms-custom-select-menu" x-show="open" x-transition.opacity.scale.origin.top style="display:none">
                                    @foreach ([
                                        '1:1' => ['1:1 (Square)', 'Perfect for marketplace & catalog'],
                                        '4:5' => ['4:5 (Portrait)', 'Social & product feed'],
                                        '3:4' => ['3:4 (Portrait)', 'Portrait product visual'],
                                        '16:9' => ['16:9 (Landscape)', 'Banner & marketplace hero'],
                                        '9:16' => ['9:16 (Story)', 'Story & vertical content'],
                                    ] as $value => $meta)
                                        <button type="button" class="{{ $aspectRatio === $value ? 'selected' : '' }}" @click="setLivewireValue('aspectRatio','{{ $value }}'); open=false">
                                            <span class="rms-option-ratio">{{ $value }}</span>
                                            <span><strong>{{ $meta[0] }}</strong><small>{{ $meta[1] }}</small></span>
                                            <i>{{ $aspectRatio === $value ? '✓' : '' }}</i>
                                        </button>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="rms-custom-select rms-custom-select-enhanced" x-data="{ open:false }" @click.outside="open=false">
                                <span class="rms-custom-select-label">Quality</span>
                                <button type="button" class="rms-custom-select-trigger" :class="{ 'is-open': open }" @click="open=!open">
                                    <span>
                                        <b x-text="qualityLabel('{{ $quality }}')"></b>
                                        <small>Output quality</small>
                                    </span>
                                    <i><svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg></i>
                                </button>
                                <div class="rms-custom-select-menu" x-show="open" x-transition.opacity.scale.origin.top style="display:none">
                                    <button type="button" class="{{ $quality === 'standard' ? 'selected' : '' }}" @click="setLivewireValue('quality','standard'); open=false">
                                        <span class="rms-option-quality standard">S</span>
                                        <span><strong>Standard</strong><small>Balanced speed & quality</small></span>
                                        <i>{{ $quality === 'standard' ? '✓' : '' }}</i>
                                    </button>
                                    <button type="button" class="{{ $quality === 'high' ? 'selected' : '' }}" @click="setLivewireValue('quality','high'); open=false">
                                        <span class="rms-option-quality high">H</span>
                                        <span><strong>High Quality</strong><small>Maximum visual detail</small></span>
                                        <i>{{ $quality === 'high' ? '✓' : '' }}</i>
                                    </button>
                                </div>
                            </div>

                            <div class="rms-custom-select full" x-data="{ open:false }" @click.outside="open=false">
                                <span class="rms-custom-select-label">Jumlah Gambar</span>
                                <button type="button" class="rms-custom-select-trigger" :class="{ 'is-open': open }" @click="open=!open">
                                    <span>
                                        <b>{{ $imageCount }} {{ $imageCount === 1 ? 'Gambar' : 'Gambar' }}</b>
                                        <small>Jumlah hasil yang akan dibuat</small>
                                    </span>
                                    <i><svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg></i>
                                </button>
                                <div class="rms-custom-select-menu" x-show="open" x-transition.opacity.scale.origin.top style="display:none">
                                    <?php foreach ([1,2,3,4] as $count): ?>
                                        <button type="button" class="{{ (int)$imageCount === $count ? 'selected' : '' }}" @click="setLivewireValue('imageCount', {{ $count }}); open=false">
                                            <span class="rms-option-count">{{ $count }}</span>
                                            <span><strong>{{ $count }} {{ $count === 1 ? 'Gambar' : 'Gambar' }}</strong><small>{{ $count === 1 ? 'Satu hasil utama' : $count . ' variasi hasil' }}</small></span>
                                            <i>{{ (int)$imageCount === $count ? '✓' : '' }}</i>
                                        </button>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button
                        type="button"
                        class="rms-generator-generate"
                        @click="generateVisual()"
                        wire:loading.attr="disabled"
                        wire:target="generate"
                        :disabled="generating"
                    >
                        <span class="rms-generate-icon" x-text="generating ? '◌' : '✦'"></span>
                        <span>
                            <strong x-text="generating ? 'Generating...' : 'Generate Gambar'"></strong>
                            <small x-text="generating ? 'OpenAI sedang membuat visual...' : 'Buat visual dengan konfigurasi saat ini'"></small>
                        </span>
                        <b>
                            <svg viewBox="0 0 24 24"><path d="M5 12h13m-5-5 5 5-5 5"/></svg>
                        </b>
                    </button>
                </section>
            </div>
        </section>

        <section class="rms-generator-history rms-generator-history-bottom" wire:key="generation-history">
            <div class="rms-generator-history-head">
                <div class="rms-history-title">
                    <span>◷</span>
                    <div>
                        <strong>Recent Generations</strong>
                        <small>Generate berikutnya bisa langsung dibuat tanpa menunggu proses sebelumnya selesai.</small>
                    </div>
                </div>
                <div class="rms-history-count"><i></i>{{ $this->recentGenerations->count() }} result</div>
            </div>

            <div class="rms-history-toolbar">
                <div class="rms-history-search">
                    <span>⌕</span>
                    <input type="text" wire:model.live.debounce.400ms="historySearch" placeholder="Cari generation, store, template...">
                </div>
                <div class="rms-history-filter-group">
                    <div class="rms-history-filter" x-data="{ open:false }" @click.outside="open=false">
                        <button type="button" @click="open=!open" :class="{ 'is-open': open }">
                            <span>Status</span><b>{{ $historyStatus === 'all' ? 'All Status' : ucfirst($historyStatus) }}</b><i>⌄</i>
                        </button>
                        <div class="rms-history-filter-menu" x-show="open" x-transition.opacity.scale.origin.top.right x-cloak>
                            <?php foreach (['all'=>'All Status','queued'=>'Queued','processing'=>'Processing','completed'=>'Completed','failed'=>'Failed'] as $value => $label): ?>
                                <button type="button" class="{{ $historyStatus === $value ? 'selected' : '' }}" wire:click="$set('historyStatus','{{ $value }}')" @click="open=false">
                                    <span>{{ $label }}</span><i>{{ $historyStatus === $value ? '✓' : '' }}</i>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="rms-history-filter" x-data="{ open:false }" @click.outside="open=false">
                        <button type="button" @click="open=!open" :class="{ 'is-open': open }">
                            <span>Store</span><b>{{ $historyStoreId ? optional($this->stores->firstWhere('id',$historyStoreId))->name : 'All Stores' }}</b><i>⌄</i>
                        </button>
                        <div class="rms-history-filter-menu" x-show="open" x-transition.opacity.scale.origin.top.right x-cloak>
                            <button type="button" class="{{ ! $historyStoreId ? 'selected' : '' }}" wire:click="$set('historyStoreId',null)" @click="open=false">
                                <span>All Stores</span><i>{{ ! $historyStoreId ? '✓' : '' }}</i>
                            </button>
                            <?php foreach ($this->stores as $store): ?>
                                <button type="button" class="{{ (int)$historyStoreId === (int)$store->id ? 'selected' : '' }}" wire:click="$set('historyStoreId',{{ $store->id }})" @click="open=false">
                                    <span>{{ $store->name }}</span><i>{{ (int)$historyStoreId === (int)$store->id ? '✓' : '' }}</i>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="rms-history-filter" x-data="{ open:false }" @click.outside="open=false">
                        <button type="button" @click="open=!open" :class="{ 'is-open': open }">
                            <span>Template</span><b>{{ $historyTemplateId ? optional($this->historyTemplates->firstWhere('id',$historyTemplateId))->name : 'All Templates' }}</b><i>⌄</i>
                        </button>
                        <div class="rms-history-filter-menu" x-show="open" x-transition.opacity.scale.origin.top.right x-cloak>
                            <button type="button" class="{{ ! $historyTemplateId ? 'selected' : '' }}" wire:click="$set('historyTemplateId',null)" @click="open=false">
                                <span>All Templates</span><i>{{ ! $historyTemplateId ? '✓' : '' }}</i>
                            </button>
                            <?php foreach ($this->historyTemplates as $template): ?>
                                <button type="button" class="{{ (int)$historyTemplateId === (int)$template->id ? 'selected' : '' }}" wire:click="$set('historyTemplateId',{{ $template->id }})" @click="open=false">
                                    <span>{{ $template->name }}</span><i>{{ (int)$historyTemplateId === (int)$template->id ? '✓' : '' }}</i>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div
                class="rms-generator-history-list"
                <?php if($this->hasActiveGenerations) : ?>
                    wire:poll.4s.visible
                <?php endif; ?>
            >
                <?php $__blade_forelse_5 = $this->recentGenerations; if ($__blade_forelse_5->isNotEmpty()): foreach ($__blade_forelse_5 as $generation): ?>
                    @php
                        $meta = $generation->metadata ?? [];
                        $progress = (int) ($meta['progress'] ?? ($generation->status === 'completed' ? 100 : 8));
                        $stage = $meta['progress_stage'] ?? ($generation->status === 'queued' ? 'Menunggu worker...' : 'Memproses...');
                        $statusLabel = match($generation->status) {
                            'queued' => 'Queued',
                            'processing' => 'Processing',
                            'completed' => 'Completed',
                            'failed' => 'Failed',
                            default => ucfirst($generation->status)
                        };
                        $images = $generation->generatedImages->take(4);
                    @endphp

                    <article wire:key="generation-history-{{ $generation->id }}" class="rms-generator-history-item status-{{ $generation->status }}">
                        <div class="rms-history-item-top">
                            <div class="rms-history-item-meta">
                                <span>{{ optional($generation->created_at)->format('d M Y · H:i') }}</span>
                                <small>#{{ $generation->id }}</small>
                            </div>
                            <span class="rms-history-status {{ $generation->status }}"><i></i>{{ $statusLabel }}</span>
                        </div>

                        <div class="rms-history-item-title">
                            <div>
                                <strong>{{ $generation->template?->name ?? 'Generated Image' }}</strong>
                                <small>{{ $generation->store?->name ?? 'Store' }} · {{ $generation->model }}</small>
                            </div>
                            <span>{{ $generation->generatedImages->count() }} image{{ $generation->generatedImages->count() === 1 ? '' : 's' }}</span>
                        </div>

                        <?php if(in_array($generation->status, ['queued','processing'])) : ?>
                            <div class="rms-history-progress">
                                <div class="rms-history-progress-icon">✦</div>
                                <div class="rms-history-progress-body">
                                    <div class="rms-history-progress-head"><span>{{ $stage }}</span><b>{{ min(99,$progress) }}%</b></div>
                                    <div class="rms-history-progress-track"><i style="width: {{ min(99,$progress) }}%"></i></div>
                                    <small>{{ $generation->status === 'queued' ? 'Sudah masuk antrean. Kamu tetap bisa membuat generation lain.' : 'AI sedang memproses di background.' }}</small>
                                </div>
                            </div>
                        <?php elseif($generation->status === 'failed') : ?>
                            <div class="rms-history-error">
                                <div class="rms-history-error-icon">!</div>
                                <div><b>Generation gagal</b><span>{{ \Illuminate\Support\Str::limit($generation->error_message ?: 'Terjadi error saat memproses generation.', 180) }}</span></div>
                            </div>
                        <?php else: ?>
                            <?php if($images->isNotEmpty()) : ?>
                                <div class="rms-history-gallery">
                                    @php $hero = $images->first(); @endphp
                                    @php
                                        $heroPreview = [
                                            'id' => (int) $hero->id,
                                            'url' => \Illuminate\Support\Facades\Storage::disk('public')->url($hero->image_path),
                                            'format' => strtoupper($hero->format ?: 'PNG'),
                                            'width' => (int) $hero->width,
                                            'height' => (int) $hero->height,
                                            'template' => $generation->template?->name ?? 'Generated Image',
                                            'store' => $generation->store?->name ?? 'Store',
                                        ];
                                    @endphp
                                    <button type="button" class="rms-history-hero" @click="openPreview({{ \Illuminate\Support\Js::from($heroPreview) }})">
                                        <img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($hero->image_path) }}" alt="" loading="lazy">
                                        <span>⌕ Preview</span>
                                    </button>
                                    <?php if($images->count() > 1) : ?>
                                        <div class="rms-history-thumbs">
                                            <?php foreach ($images->skip(1) as $image): ?>
                                                @php
                                                    $thumbPreview = [
                                                        'id' => (int) $image->id,
                                                        'url' => \Illuminate\Support\Facades\Storage::disk('public')->url($image->image_path),
                                                        'format' => strtoupper($image->format ?: 'PNG'),
                                                        'width' => (int) $image->width,
                                                        'height' => (int) $image->height,
                                                        'template' => $generation->template?->name ?? 'Generated Image',
                                                        'store' => $generation->store?->name ?? 'Store',
                                                    ];
                                                @endphp
                                                <button type="button" class="rms-history-thumb" @click="openPreview({{ \Illuminate\Support\Js::from($thumbPreview) }})">
                                                    <img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($image->image_path) }}" alt="" loading="lazy">
                                                </button>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="rms-history-no-image">Generation selesai, tetapi hasil gambar belum tersedia.</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </article>
                <?php endforeach; else: ?>
                    <div class="rms-history-empty">
                        <span>✦</span>
                        <strong>Belum ada generation</strong>
                        <small>Hasil baru akan muncul di sini. Kamu bisa menjalankan beberapa generation tanpa menunggu satu per satu.</small>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </div>
    {{-- ============================================================
     GENERATED IMAGE PREVIEW
     IMPORTANT:
     Modal is teleported outside Livewire DOM so wire:poll/morph
     cannot destroy or recreate the modal state.
    ============================================================ --}}

    <template x-teleport="body">

        <div
            x-cloak
            x-show="previewOpen"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            class="rms-generator-preview-modal"
            role="dialog"
            aria-modal="true"
            aria-label="Generated image preview"
            @keydown.escape.window="closePreview()"
        >

            {{-- BACKDROP --}}
            <div
                class="rms-preview-backdrop"
                @click="closePreview()"
            ></div>


            {{-- DIALOG --}}
            <div
                class="rms-preview-dialog"
                @click.stop
            >

                {{-- CLOSE --}}
                <button
                    type="button"
                    class="rms-preview-close"
                    aria-label="Close preview"
                    @click.prevent.stop="closePreview()"
                >
                    <span aria-hidden="true">×</span>
                </button>


                {{-- ==================================================
                    IMAGE AREA
                =================================================== --}}
                <section class="rms-preview-media">

                    {{-- IMAGE --}}
                    <template
                        x-if="
                            previewImage &&
                            previewImage.url &&
                            !previewImageError
                        "
                    >
                        <img
                            :src="previewImage.url"
                            alt="Generated image preview"
                            class="rms-preview-image"
                            @error="handlePreviewImageError()"
                        >
                    </template>


                    {{-- EMPTY / ERROR --}}
                    <template
                        x-if="
                            !previewImage ||
                            !previewImage.url ||
                            previewImageError
                        "
                    >
                        <div class="rms-preview-empty">

                            <div class="rms-preview-empty-icon">
                                <span>⌁</span>
                            </div>

                            <strong>
                                Preview tidak tersedia
                            </strong>

                            <small>
                                Gambar belum dapat dimuat atau belum dipilih.
                            </small>

                        </div>
                    </template>

                </section>


                {{-- ==================================================
                    SIDEBAR
                =================================================== --}}
                <aside class="rms-preview-sidebar">

                    {{-- HEADER --}}
                    <div class="rms-preview-sidebar-header">

                        <div>

                            <span class="rms-preview-kicker">
                                GENERATED RESULT
                            </span>

                            <h3
                                x-text="
                                    previewImage?.template ||
                                    'Generated Image'
                                "
                            ></h3>

                            <p
                                x-text="
                                    previewImage?.store ||
                                    'Store'
                                "
                            ></p>

                        </div>

                        {{-- Mobile close --}}
                        <button
                            type="button"
                            class="rms-preview-mobile-close"
                            aria-label="Close preview"
                            @click.prevent.stop="closePreview()"
                        >
                            ×
                        </button>

                    </div>


                    {{-- SPECS --}}
                    <div class="rms-preview-specs">

                        <div class="rms-preview-spec">

                            <span>
                                FORMAT
                            </span>

                            <strong
                                x-text="
                                    previewImage?.format ||
                                    '—'
                                "
                            ></strong>

                        </div>


                        <div class="rms-preview-spec">

                            <span>
                                RESOLUTION
                            </span>

                            <strong
                                x-text="
                                    previewImage?.width &&
                                    previewImage?.height
                                        ? `${previewImage.width} × ${previewImage.height}`
                                        : 'Original'
                                "
                            ></strong>

                        </div>

                    </div>


                    {{-- DOWNLOAD --}}
                    <div class="rms-preview-download">

                        <div class="rms-preview-download-header">

                            <strong>
                                Download
                            </strong>

                            <span>
                                Default: ≤ 2 MB
                            </span>

                        </div>


                        {{-- DEFAULT --}}
                        <a
                            class="rms-preview-download-primary"
                            :href="downloadUrl(2, 85, 'jpg')"
                            :class="{
                                'is-disabled': !previewImage?.id
                            }"
                            @click="
                                if (!previewImage?.id)
                                    $event.preventDefault()
                            "
                        >

                            <span>
                                ↓
                            </span>

                            <strong>
                                Optimized · ≤ 2 MB
                            </strong>

                        </a>


                        {{-- OPTIONS --}}
                        <div class="rms-preview-download-options">

                            {{-- JPG HIGH --}}
                            <a
                                :href="downloadUrl(2, 90, 'jpg')"
                                @click="
                                    if (!previewImage?.id)
                                        $event.preventDefault()
                                "
                            >
                                <b>JPG</b>
                                <span>High · ≤ 2 MB</span>
                                <i>→</i>
                            </a>


                            {{-- JPG BALANCED --}}
                            <a
                                :href="downloadUrl(2, 75, 'jpg')"
                                @click="
                                    if (!previewImage?.id)
                                        $event.preventDefault()
                                "
                            >
                                <b>JPG</b>
                                <span>Balanced · ≤ 2 MB</span>
                                <i>→</i>
                            </a>


                            {{-- JPG 3MB --}}
                            <a
                                :href="downloadUrl(3, 90, 'jpg')"
                                @click="
                                    if (!previewImage?.id)
                                        $event.preventDefault()
                                "
                            >
                                <b>JPG</b>
                                <span>High · ≤ 3 MB</span>
                                <i>→</i>
                            </a>


                            {{-- WEBP --}}
                            <a
                                :href="downloadUrl(1, 78, 'webp')"
                                @click="
                                    if (!previewImage?.id)
                                        $event.preventDefault()
                                "
                            >
                                <b>WEBP</b>
                                <span>Compact · ≤ 1 MB</span>
                                <i>→</i>
                            </a>

                        </div>

                    </div>

                </aside>

            </div>

        </div>

    </template>
</div>